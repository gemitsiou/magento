# Viva Payments Smart Checkout for Magento

This build adds verified server-side polling, payment-attempt history and product-driven preauthorization.

## Installation / upgrade

After copying the module, run:

```bash
bin/magento module:enable Ced_VivaPayments
bin/magento setup:upgrade
bin/magento setup:di:compile
bin/magento cache:flush
```

For production mode, deploy static content according to the Magento installation's normal release process.

## Required polling worker

Magento cron runs at most once per minute and cannot guarantee a sub-minute interval. Run exactly one persistent worker under systemd, Supervisor, Kubernetes or another process manager:

```bash
bin/magento viva:payments:poll
```

The worker safely serializes processing by payment attempt. A once-per-minute Magento cron job is included only as a fallback. Configuration is under **Stores > Configuration > Sales > Payment Methods > Viva Wallet Smart Checkout**:

- Enable Background Polling (default Yes)
- Initial Polling Delay in seconds (default 120; background only)
- Polling Interval in seconds (default 30)
- Payment Timeout in seconds (default 1800)

The timeout is also sent to `POST /api/orders` as `paymentTimeout`. Each attempt stores its own expiry and initial delay. The callback always performs its final lookup immediately and never waits for the initial delay. The persistent worker reloads Admin configuration every 30 seconds.

A production systemd unit and installer are included under `deployment/systemd`. Install it once after the module upgrade. It automatically starts at boot, restarts after failures, and gracefully recycles without losing database-backed payment state.

## Preauthorization

Products include a **Viva Preauthorization** Yes/No attribute. If at least one visible basket item has Yes, the complete Viva payment order uses `isPreAuth=true`, with installments forced to 1. The flag is snapshotted onto the quote and sales order.

A successful preauthorization (`StatusId=F` on an attempt already marked as preauthorization) does not create an invoice. `TransactionTypeId` is recorded but never used as a validation filter. The order view shows:

- **Capture**: opens the standard Magento invoice screen. Selected quantities determine the one allowed full or partial capture. After success, any un-invoiced quantities are cancelled and returned to stock when Magento inventory management is enabled.
- **Cancel Preauth**: releases the complete authorized amount and cancels the Magento order without an invoice or credit memo.

Refunds after capture use the capture transaction ID. Preauthorization, capture, cancellation and refund transactions remain as separate parent/child history records.

## Verification rules

Transactions are retrieved only with `GET /api/transactions/?ordercode={VivaOrderCode}`. Callback parameter `t`, when supplied, must exactly match a returned `TransactionId`; there is no fallback to the latest transaction. A successful payment also requires matching nested `Order.OrderCode`, Magento Order Increment ID in `MerchantTrns`, amount, and a non-empty `TransactionId`. `CurrencyCode`, `ErrorCode`, and `TransactionTypeId` are recorded but are not validation filters.

For QA diagnostics, the complete transaction response returned by Viva is persisted and displayed in the Magento order Admin view, including Payment and CreditCard objects.

## Customer Back-button cancellation

When Viva returns the customer with `cancel=1`, transaction polling stops immediately and the module calls `DELETE /api/orders/{orderCode}` before cancelling the Magento order and restoring the basket. Technical DELETE failures use exponential retries of 10, 20, 40, 80, 160, then 300 seconds until the original payment expiry.
