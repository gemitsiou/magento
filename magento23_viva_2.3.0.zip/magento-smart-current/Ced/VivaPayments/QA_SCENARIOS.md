# Viva Payments 2.3.0 QA scenarios

Defaults: background polling enabled, initial delay 120 seconds, polling interval 30 seconds, payment timeout 1800 seconds.

| Scenario | Expected result |
| --- | --- |
| Background lookup returns `Transactions: []` before expiry | Attempt remains Pending; no invoice/cancellation; next lookup is scheduled. |
| Final valid lookup returns `Transactions: []` at/after expiry | Attempt becomes Expired; Magento order is cancelled and stock is released. |
| Background lookup returns matching `StatusId=E` before expiry | Attempt remains Pending and polling continues. |
| A later lookup returns matching `StatusId=F` | Attempt becomes Success; normal payment creates one invoice, preauth creates no invoice. |
| Final timeout lookup returns matching `StatusId=E` | Attempt becomes Failed; Magento order is cancelled and stock is released. |
| Lookup returns matching `StatusId=A` before expiry | Attempt remains Pending. |
| Lookup returns matching `StatusId=X` | Attempt becomes Failed/Cancelled; Magento order is cancelled and stock is released. |
| Lookup unexpectedly returns `StatusId=R` for an active attempt | Verification Error/Pending reconciliation; it is never treated as a new successful payment. |
| Callback returns matching `StatusId=F` | Callback processes immediately, stops polling and redirects to success. |
| Callback returns matching `StatusId=E` | Attempt becomes Failed; order is cancelled; basket and stock are restored. |
| Callback returns `Transactions: []` before expiry | Attempt remains Pending for reconciliation; polling stops; quote is not restored. |
| Callback returns `Transactions: []` after expiry | Attempt becomes Expired; order is cancelled; basket and stock are restored. |
| Callback `t` is not present in returned transactions | Verification Error; no fallback transaction; no invoice/cancellation. |
| `Order.OrderCode`, `MerchantTrns`, or amount does not match | Verification Error; no invoice/cancellation. |
| `CurrencyCode`, `ErrorCode`, or `TransactionTypeId` differs | Difference is recorded but does not reject an otherwise valid transaction. |
| HTTP/network/invalid JSON before expiry | Pending and retry during background polling. |
| HTTP/network/invalid JSON on final callback/timeout lookup | Pending for reconciliation; no invoice/cancellation. |
| Duplicate success callback | No duplicate invoice or payment processing. |
| Multiple matching transactions include `F` | Matching `F` is selected; otherwise newest `InsDate` is selected. |
| Callback includes `cancel=1` | Polling stops, DELETE `/api/orders/{orderCode}` runs immediately, order is cancelled and basket/stock restored. |
| Initial cancellation DELETE has technical failure | Magento remains Cancelled; DELETE retries at 10, 20, 40, 80, 160, then 300-second intervals until original expiry. |
| Admin changes polling settings while worker runs | New values are observed within 30 seconds without manual worker restart. |
| Worker receives SIGTERM or reaches one-hour runtime | It exits between cycles; systemd restarts it without losing database-backed state. |

For each scenario verify `var/log/system.log`, Magento order history, Viva Payment Information in Admin, invoice count, stock quantity, and the `vivapayments_data`/`vivapayments_transaction` records.
