<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Service;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;

/** Browser-independent transaction polling and Viva payment-order cancellation worker. */
class PaymentPoller
{
    private VivaApiClient $api;
    private AttemptManager $attempts;
    private OrderProcessor $orders;
    private ScopeConfigInterface $scopeConfig;
    private LoggerInterface $logger;

    public function __construct(
        VivaApiClient $api,
        AttemptManager $attempts,
        OrderProcessor $orders,
        ScopeConfigInterface $scopeConfig,
        LoggerInterface $logger
    ) {
        $this->api = $api;
        $this->attempts = $attempts;
        $this->orders = $orders;
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
    }

    public function pollDue(int $limit = 100): int
    {
        $processed = 0;

        // Customer-requested DELETE retries have priority and are independent of polling_enabled.
        foreach ($this->attempts->getDueCancellationRetries($limit) as $attempt) {
            try {
                $this->retryPaymentOrderCancellation($attempt);
                $processed++;
            } catch (\Throwable $e) {
                $this->logger->error('Viva payment order cancellation worker failure', [
                    'order_code' => $attempt['ordercode'], 'error' => $e->getMessage(),
                ]);
            }
        }
        $this->attempts->expireCancellationRetries();

        foreach ($this->attempts->getExpiredAttempts($limit) as $attempt) {
            if (!$this->isPollingEnabled((int) $attempt['store_id'])) {
                continue;
            }
            try {
                $this->pollAttempt($attempt, true, null, true);
                $processed++;
            } catch (\Throwable $e) {
                $this->logger->error('Viva final timeout poll failed', [
                    'order_code' => $attempt['ordercode'], 'error' => $e->getMessage(),
                ]);
            }
        }

        foreach ($this->attempts->getDueAttempts($limit) as $attempt) {
            if (!$this->isPollingEnabled((int) $attempt['store_id'])) {
                continue;
            }
            try {
                $this->pollAttempt($attempt, false);
                $processed++;
            } catch (\Throwable $e) {
                $this->logger->error('Viva polling attempt failed', [
                    'order_code' => $attempt['ordercode'], 'error' => $e->getMessage(),
                ]);
            }
        }
        return $processed;
    }

    /** Callback calls use final=true and never wait for the background polling schedule. */
    public function pollAttempt(
        array $attempt,
        bool $final,
        ?string $callbackTransactionId = null,
        bool $timeout = false
    ): array {
        return $this->attempts->withLock(
            (int) $attempt['id'],
            function () use ($attempt, $final, $callbackTransactionId, $timeout): array {
                $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
                if (!$fresh) {
                    throw new \RuntimeException('Payment attempt no longer exists.');
                }
                if (empty($fresh['polling_active'])
                    && in_array($fresh['order_state'], ['paid', 'preauth_payment'], true)
                ) {
                    $stored = json_decode((string) ($fresh['response_data'] ?? ''), true) ?: [];
                    if ($callbackTransactionId !== null
                        && (string) ($stored['TransactionId'] ?? '') !== $callbackTransactionId
                    ) {
                        return $this->result(
                            'verification_error',
                            'The callback transaction ID does not match the processed transaction.'
                        );
                    }
                    return [
                        'verified' => true, 'state' => $fresh['order_state'],
                        'transaction_id' => (string) ($stored['TransactionId'] ?? ''),
                        'amount' => (float) ($stored['Amount'] ?? 0), 'status_id' => 'F',
                        'message' => 'Transaction was already processed.', 'error_type' => '',
                        'response_type' => 'transaction', 'transaction' => $stored,
                    ];
                }
                return $this->processAttempt($fresh, $final, $callbackTransactionId, $timeout);
            }
        );
    }

    /** Handle cancel=1: stop polling first, immediately DELETE the Viva order. */
    public function cancelPaymentOrder(array $attempt): array
    {
        return $this->attempts->withLock((int) $attempt['id'], function () use ($attempt): array {
            $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
            if (!$fresh) {
                throw new \RuntimeException('Payment attempt no longer exists.');
            }
            $this->attempts->requestCustomerCancellation((int) $fresh['id']);
            $result = $this->api->cancelPaymentOrder(
                (string) $fresh['ordercode'], (int) $fresh['store_id']
            );
            $this->attempts->recordCancellationAttempt((int) $fresh['id'], $result);
            $this->logger->info('Viva customer cancellation state transition', [
                'order_code' => $fresh['ordercode'], 'magento_order' => $fresh['order_id'],
                'from' => $fresh['order_state'], 'to' => 'cancelled', 'delete_result' => $result,
            ]);
            return $result;
        });
    }

    private function retryPaymentOrderCancellation(array $attempt): void
    {
        $this->attempts->withLock((int) $attempt['id'], function () use ($attempt): void {
            $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
            if (!$fresh || empty($fresh['cancel_retry_active'])) {
                return;
            }
            $result = $this->api->cancelPaymentOrder(
                (string) $fresh['ordercode'], (int) $fresh['store_id']
            );
            $this->attempts->recordCancellationAttempt((int) $fresh['id'], $result);
        });
    }

    private function processAttempt(
        array $attempt,
        bool $final,
        ?string $callbackTransactionId,
        bool $timeout
    ): array {
        $storeId = isset($attempt['store_id']) ? (int) $attempt['store_id'] : null;
        $expected = [
            'order_code' => (string) $attempt['ordercode'],
            'merchant_trns' => (string) $attempt['order_id'],
            'amount_cents' => (int) $attempt['amount_cents'],
        ];
        $result = $this->api->verifyTransaction(
            (string) $attempt['ordercode'], $callbackTransactionId, $storeId, $expected
        );
        $transaction = $result['transaction'] ?? [];
        if ($transaction !== []) {
            $this->attempts->recordTransaction(
                (int) $attempt['id'],
                !empty($attempt['is_preauth']) ? 'preauthorization' : 'payment',
                $transaction
            );
        }

        if (!empty($result['verified'])) {
            $order = $this->orders->loadOrder((string) $attempt['order_id']);
            if (!empty($attempt['is_preauth'])) {
                $this->orders->processSuccessfulPreauthorization(
                    $order, (string) $result['transaction_id'], (float) $result['amount'],
                    (string) $result['message']
                );
                $state = 'preauth_payment';
            } else {
                $this->orders->processSuccessfulPayment(
                    $order, (string) $result['transaction_id'], (float) $result['amount'],
                    (string) $result['message']
                );
                $state = 'paid';
            }
            $this->attempts->stop((int) $attempt['id'], $state, 'successful_transaction', $transaction);
            $result['state'] = $state;
            $this->logTransition($attempt, $state, $result);
            return $result;
        }

        $state = $this->resolveState($result, $final, $timeout);
        $result['state'] = $state;
        if (in_array($state, ['failed', 'expired'], true)) {
            $order = $this->orders->loadOrder((string) $attempt['order_id']);
            if ($state === 'expired') {
                $this->orders->processExpiredPayment($order, (string) $result['message']);
            } else {
                $this->orders->processFailedPayment($order, (string) $result['message']);
            }
            $this->attempts->stop(
                (int) $attempt['id'], $state,
                $timeout ? 'payment_timeout' : 'terminal_payment_status', $transaction
            );
        } elseif ($final) {
            $order = $this->orders->loadOrder((string) $attempt['order_id']);
            $this->orders->processPendingReconciliation($order, (string) $result['message']);
            $storedState = $state === 'verification_error' ? 'verification_error' : 'pending';
            $this->attempts->stop(
                (int) $attempt['id'], $storedState,
                $timeout ? 'payment_timeout_reconciliation' : 'customer_return', $transaction
            );
        } else {
            $this->attempts->markPolled(
                (int) $attempt['id'], $this->getInterval($storeId), 'pending', $transaction
            );
        }
        $this->logTransition($attempt, $state, $result);
        return $result;
    }

    private function resolveState(array $result, bool $final, bool $timeout): string
    {
        $type = (string) ($result['response_type'] ?? 'technical_error');
        if ($type === 'technical_error' || $type === 'verification_error') {
            return 'verification_error';
        }
        if ($type === 'empty') {
            return $timeout ? 'expired' : 'pending';
        }
        switch (strtoupper((string) ($result['status_id'] ?? ''))) {
            case 'F': return 'verification_error';
            case 'E': return ($final || $timeout) ? 'failed' : 'pending';
            case 'A': return $timeout ? 'expired' : 'pending';
            case 'X': return 'failed';
            case 'R': return 'verification_error';
            default: return $final ? 'verification_error' : 'pending';
        }
    }

    private function result(string $state, string $message): array
    {
        return [
            'verified' => false, 'state' => $state, 'transaction_id' => '',
            'amount' => 0.0, 'status_id' => '', 'message' => $message,
            'error_type' => 'verification', 'response_type' => 'verification_error',
            'transaction' => [],
        ];
    }

    private function isPollingEnabled(int $storeId): bool
    {
        return (bool) $this->scopeConfig->getValue(
            'payment/paymentmethod/polling_enabled', ScopeInterface::SCOPE_STORE, $storeId
        );
    }

    public function getInterval(?int $storeId = null): int
    {
        $value = (int) $this->scopeConfig->getValue(
            'payment/paymentmethod/polling_interval', ScopeInterface::SCOPE_STORE, $storeId
        );
        return max(5, $value > 0 ? $value : 30);
    }

    /** Recalculate pending schedules after the long-running worker reloads Admin configuration. */
    public function refreshSchedulesFromConfiguration(): void
    {
        $storeConfig = [];
        foreach ($this->attempts->getActiveAttemptsForScheduling() as $attempt) {
            $storeId = (int) $attempt['store_id'];
            if (!isset($storeConfig[$storeId])) {
                $delay = (int) $this->scopeConfig->getValue(
                    'payment/paymentmethod/initial_polling_delay',
                    ScopeInterface::SCOPE_STORE,
                    $storeId
                );
                $storeConfig[$storeId] = [
                    'delay' => $delay > 0 ? $delay : 120,
                    'interval' => $this->getInterval($storeId),
                ];
            }
            $firstPoll = (int) $attempt['poll_attempts'] === 0;
            $base = $firstPoll ? (string) $attempt['started_at'] : (string) $attempt['last_polled_at'];
            $baseTimestamp = strtotime($base);
            if ($baseTimestamp === false) {
                continue;
            }
            $seconds = $firstPoll
                ? $storeConfig[$storeId]['delay']
                : $storeConfig[$storeId]['interval'];
            $next = gmdate('Y-m-d H:i:s', $baseTimestamp + $seconds);
            if ($next !== (string) $attempt['next_poll_at']) {
                $this->attempts->reschedule(
                    (int) $attempt['id'],
                    $next,
                    $firstPoll ? $storeConfig[$storeId]['delay'] : null
                );
            }
        }
    }

    private function logTransition(array $attempt, string $state, array $result): void
    {
        $this->logger->info('Viva payment state transition', [
            'order_code' => $attempt['ordercode'], 'magento_order' => $attempt['order_id'],
            'from' => $attempt['order_state'], 'to' => $state,
            'transaction_id' => $result['transaction_id'] ?? '',
            'status_id' => $result['status_id'] ?? '',
            'failed_criteria' => $result['message'] ?? '',
            'transaction' => $result['transaction'] ?? [],
        ]);
    }
}
