<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Block\Adminhtml\Order;

use Ced\VivaPayments\Service\AttemptManager;
use Magento\Backend\Block\Template;
use Magento\Framework\Registry;

class VivaInfo extends Template
{
    private Registry $registry;
    private AttemptManager $attempts;
    public function __construct(Template\Context $context, Registry $registry, AttemptManager $attempts, array $data = [])
    { parent::__construct($context, $data); $this->registry = $registry; $this->attempts = $attempts; }

    public function getAttempt(): ?array
    {
        $order = $this->registry->registry('current_order');
        if (!$order || !$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') { return null; }
        return $this->attempts->getLatestByOrder((string) $order->getIncrementId());
    }

    public function getAttempts(): array
    {
        $order = $this->registry->registry('current_order');
        if (!$order || !$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') { return []; }
        return $this->attempts->getByOrder((string) $order->getIncrementId());
    }

    public function getStatusLabel(string $state): string
    {
        $labels = [
            'pending' => 'Pending', 'unsuccessful_retrying' => 'Unsuccessful – Retrying',
            'paid' => 'Paid', 'unsuccessful' => 'Unsuccessful', 'cancelled' => 'Cancelled',
            'expired' => 'Expired', 'verification_error_retrying' => 'Verification Error – Retrying',
            'verification_error' => 'Verification Error', 'preauth_payment' => 'Preauth Payment',
            'preauth_captured' => 'Preauth Captured', 'preauth_cancelled' => 'Preauth Cancelled',
            'partially_refunded' => 'Partially Refunded', 'refunded' => 'Refunded',
        ];
        return $labels[$state] ?? ucwords(str_replace('_', ' ', $state));
    }

    public function getVivaStatusDescription(string $status): string
    {
        return [
            'F' => 'Payment successful', 'E' => 'Payment unsuccessful', 'A' => 'Payment pending',
            'R' => 'Fully or partially refunded', 'X' => 'Cancelled by merchant',
        ][strtoupper($status)] ?? 'Unknown';
    }

    public function getTransactions(int $attemptId): array
    {
        $rows = $this->attempts->getTransactions($attemptId);
        foreach ($rows as &$row) {
            $raw = json_decode((string) $row['response_data'], true) ?: [];
            $row['details'] = [
                'TotalInstallments' => $raw['TotalInstallments'] ?? '',
                'SourceCode' => $raw['SourceCode'] ?? '',
                'IsManualRefund' => isset($raw['IsManualRefund']) ? ($raw['IsManualRefund'] ? 'Yes' : 'No') : '',
                'AuthorizationId' => $raw['AuthorizationId'] ?? '',
                'SurchargeAmount' => $raw['SurchargeAmount'] ?? '',
                'CreditCard' => $this->safeCard($raw['CreditCard'] ?? []),
            ];
        }
        return $rows;
    }

    private function safeCard($card): string
    {
        if (!is_array($card)) { return ''; }
        $safe = [];
        foreach (['Token', 'Number', 'MaskedNumber', 'CountryCode', 'IssuingBank', 'CardHolderName', 'ExpirationDate', 'CardTypeId'] as $key) {
            if (isset($card[$key]) && !in_array($key, ['Token'], true)) { $safe[$key] = $card[$key]; }
        }
        if (isset($safe['Number'])) { $safe['Number'] = preg_replace('/\d(?=\d{4})/', '*', (string) $safe['Number']); }
        return !empty($safe) ? json_encode($safe, JSON_UNESCAPED_SLASHES) : '';
    }
}
