<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

/** Snapshots the product rule onto quote and order at placement time. */
class SnapshotPreauthorization implements ObserverInterface
{
    public function execute(Observer $observer): void
    {
        $quote = $observer->getEvent()->getQuote();
        $order = $observer->getEvent()->getOrder();
        if (!$quote || !$order) { return; }
        $isPreAuth = false;
        foreach ($quote->getAllVisibleItems() as $item) {
            $product = $item->getProduct();
            if ($product && (bool) $product->getData('viva_is_preauth')) { $isPreAuth = true; break; }
        }
        $quote->setData('viva_is_preauth', $isPreAuth ? 1 : 0);
        $order->setData('viva_is_preauth', $isPreAuth ? 1 : 0);
    }
}
