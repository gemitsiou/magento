<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Service;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;

/** Server-side polling processor. It never depends on the customer's browser session. */
class PaymentPoller
{
    private VivaApiClient $api;
    private AttemptManager $attempts;
    private OrderProcessor $orders;
    private ScopeConfigInterface $scopeConfig;
    private LoggerInterface $logger;

    public function __construct(
        VivaApiClient $api,
        AttemptManager $attempts,
        OrderProcessor $orders,
        ScopeConfigInterface $scopeConfig,
        LoggerInterface $logger
    ) {
        $this->api = $api;
        $this->attempts = $attempts;
        $this->orders = $orders;
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
    }

    public function pollDue(int $limit = 100): int
    {
        $processed = 0;
        foreach ($this->attempts->getExpiredAttempts($limit) as $attempt) {
            if (!(bool) $this->scopeConfig->getValue(
                'payment/paymentmethod/polling_enabled', ScopeInterface::SCOPE_STORE, (int) $attempt['store_id']
            )) { continue; }
            try {
                // One final lookup at the deadline prevents losing a transaction completed near expiry.
                $this->pollAttempt($attempt, true, null, true);
                $processed++;
            } catch (\Throwable $e) {
                $this->logger->error('Viva final timeout poll failed', ['order_code' => $attempt['ordercode'], 'error' => $e->getMessage()]);
            }
        }
        // Ensure permanently failing timeout lookups cannot remain active indefinitely.
        $this->attempts->expireDue();
        foreach ($this->attempts->getDueAttempts($limit) as $attempt) {
            if (!(bool) $this->scopeConfig->getValue(
                'payment/paymentmethod/polling_enabled', ScopeInterface::SCOPE_STORE, (int) $attempt['store_id']
            )) { continue; }
            try {
                $this->pollAttempt($attempt, false);
                $processed++;
            } catch (\Throwable $e) {
                $this->logger->error('Viva polling attempt failed', [
                    'order_code' => $attempt['ordercode'], 'error' => $e->getMessage(),
                ]);
            }
        }
        return $processed;
    }

    /** Poll one attempt. Callback uses final=true and therefore always stops it. */
    public function pollAttempt(
        array $attempt,
        bool $final,
        ?string $callbackTransactionId = null,
        bool $timeout = false
    ): array
    {
        return $this->attempts->withLock((int) $attempt['id'], function () use ($attempt, $final, $callbackTransactionId, $timeout): array {
            $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
            if (!$fresh) { throw new \RuntimeException('Payment attempt no longer exists.'); }
            // A completed attempt is immutable; return its stored successful result to duplicate callbacks.
            if (empty($fresh['polling_active']) && in_array($fresh['order_state'], ['paid', 'preauth_payment'], true)) {
                $stored = json_decode((string) ($fresh['response_data'] ?? ''), true) ?: [];
                if ($callbackTransactionId !== null
                    && (string) ($stored['TransactionId'] ?? '') !== $callbackTransactionId
                ) {
                    return [
                        'verified' => false, 'transaction_id' => '', 'amount' => 0.0,
                        'status_id' => '', 'message' => 'The callback transaction ID does not match the processed transaction.',
                        'error_type' => 'verification', 'transaction' => [],
                    ];
                }
                return [
                    'verified' => true, 'transaction_id' => (string) ($stored['TransactionId'] ?? ''),
                    'amount' => (float) ($stored['Amount'] ?? 0), 'status_id' => 'F',
                    'message' => 'Transaction was already processed.', 'transaction' => $stored,
                ];
            }
            return $this->processAttempt($fresh, $final, $callbackTransactionId, $timeout);
        });
    }

    private function processAttempt(
        array $attempt,
        bool $final,
        ?string $callbackTransactionId = null,
        bool $timeout = false
    ): array
    {
        $storeId = isset($attempt['store_id']) ? (int) $attempt['store_id'] : null;
        $expected = [
            'order_code' => (string) $attempt['ordercode'],
            'merchant_trns' => (string) $attempt['order_id'],
            'amount_cents' => (int) $attempt['amount_cents'],
            'currency_code' => (int) $attempt['currency_code'],
            'transaction_type_id' => !empty($attempt['is_preauth']) ? 1 : 0,
        ];
        $result = $this->api->verifyTransaction(
            (string) $attempt['ordercode'], $callbackTransactionId, $storeId, $expected
        );
        $transaction = $result['transaction'] ?? [];
        if (!empty($transaction)) {
            $this->attempts->recordTransaction(
                (int) $attempt['id'], !empty($attempt['is_preauth']) ? 'preauthorization' : 'payment', $transaction
            );
        }

        if (!empty($result['verified'])) {
            $order = $this->orders->loadOrder((string) $attempt['order_id']);
            if (!empty($attempt['is_preauth'])) {
                $this->orders->processSuccessfulPreauthorization(
                    $order, (string) $result['transaction_id'], (float) $result['amount'], (string) $result['message']
                );
                $state = 'preauth_payment';
            } else {
                $this->orders->processSuccessfulPayment(
                    $order, (string) $result['transaction_id'], (float) $result['amount'], (string) $result['message']
                );
                $state = 'paid';
            }
            $this->attempts->stop((int) $attempt['id'], $state, 'successful_transaction', $transaction);
            return $result;
        }

        $state = $timeout ? $this->mapTimeoutState($result) : $this->mapState($result, $final);
        if ($final) {
            $this->attempts->stop(
                (int) $attempt['id'], $state, $timeout ? 'payment_timeout' : 'customer_return', $transaction
            );
        } else {
            $this->attempts->markPolled((int) $attempt['id'], $this->getInterval($storeId), $state, $transaction);
        }
        return $result;
    }

    private function mapTimeoutState(array $result): string
    {
        if (in_array(($result['error_type'] ?? ''), ['verification', 'api'], true)) { return 'verification_error'; }
        if (strtoupper((string) ($result['status_id'] ?? '')) === 'E') { return 'unsuccessful'; }
        if (strtoupper((string) ($result['status_id'] ?? '')) === 'X') { return 'cancelled'; }
        return 'expired';
    }

    private function mapState(array $result, bool $final): string
    {
        if (in_array(($result['error_type'] ?? ''), ['verification', 'api'], true)) {
            return $final ? 'verification_error' : 'verification_error_retrying';
        }
        switch (strtoupper((string) ($result['status_id'] ?? ''))) {
            case 'A': return 'pending';
            case 'E': return $final ? 'unsuccessful' : 'unsuccessful_retrying';
            case 'R': return 'refunded';
            case 'X': return 'cancelled';
            default: return 'pending';
        }
    }

    public function getInterval(?int $storeId = null): int
    {
        $value = (int) $this->scopeConfig->getValue(
            'payment/paymentmethod/polling_interval', ScopeInterface::SCOPE_STORE, $storeId
        );
        return $value > 0 ? $value : 5;
    }
}
