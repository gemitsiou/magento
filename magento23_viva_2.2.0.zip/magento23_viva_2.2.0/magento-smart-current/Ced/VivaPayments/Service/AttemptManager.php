<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Service;

use Magento\Framework\App\ResourceConnection;

/** Persistence and idempotency boundary for payment attempts and their transactions. */
class AttemptManager
{
    private ResourceConnection $resource;

    public function __construct(ResourceConnection $resource)
    {
        $this->resource = $resource;
    }

    public function create(array $data): void
    {
        $connection = $this->resource->getConnection();
        $table = $this->resource->getTableName('vivapayments_data');
        $data['attempt_no'] = (int) $connection->fetchOne(
            $connection->select()->from($table, new \Zend_Db_Expr('COALESCE(MAX(attempt_no), 0) + 1'))
                ->where('order_id = ?', $data['order_id'])
        );
        $connection->insert($table, $data);
    }

    public function getByOrderCode(string $orderCode): ?array
    {
        $connection = $this->resource->getConnection();
        $row = $connection->fetchRow(
            $connection->select()->from($this->resource->getTableName('vivapayments_data'))
                ->where('ordercode = ?', $orderCode)->limit(1)
        );
        return $row ?: null;
    }

    public function getLatestByOrder(string $incrementId): ?array
    {
        $connection = $this->resource->getConnection();
        $row = $connection->fetchRow(
            $connection->select()->from($this->resource->getTableName('vivapayments_data'))
                ->where('order_id = ?', $incrementId)->order('id DESC')->limit(1)
        );
        return $row ?: null;
    }

    public function getByOrder(string $incrementId): array
    {
        $connection = $this->resource->getConnection();
        return $connection->fetchAll(
            $connection->select()->from($this->resource->getTableName('vivapayments_data'))
                ->where('order_id = ?', $incrementId)->order('id DESC')
        );
    }

    public function getDueAttempts(int $limit = 100): array
    {
        $connection = $this->resource->getConnection();
        return $connection->fetchAll(
            $connection->select()->from($this->resource->getTableName('vivapayments_data'))
                ->where('polling_active = ?', 1)
                ->where('expires_at > UTC_TIMESTAMP()')
                ->where('next_poll_at IS NULL OR next_poll_at <= UTC_TIMESTAMP()')
                ->order('next_poll_at ASC')->limit($limit)
        );
    }

    public function getExpiredAttempts(int $limit = 100): array
    {
        $connection = $this->resource->getConnection();
        return $connection->fetchAll(
            $connection->select()->from($this->resource->getTableName('vivapayments_data'))
                ->where('polling_active = ?', 1)->where('expires_at <= UTC_TIMESTAMP()')
                ->order('expires_at ASC')->limit($limit)
        );
    }

    public function markPolled(int $id, int $interval, string $state, array $response = []): void
    {
        $response = $this->sanitize($response);
        $this->resource->getConnection()->update(
            $this->resource->getTableName('vivapayments_data'),
            [
                'order_state' => $state,
                'last_polled_at' => gmdate('Y-m-d H:i:s'),
                'next_poll_at' => gmdate('Y-m-d H:i:s', time() + max(1, $interval)),
                'poll_attempts' => new \Zend_Db_Expr('poll_attempts + 1'),
                'response_data' => !empty($response) ? json_encode($response, JSON_UNESCAPED_SLASHES) : null,
            ],
            ['id = ?' => $id]
        );
    }

    public function stop(int $id, string $state, string $reason, array $response = []): void
    {
        $response = $this->sanitize($response);
        $this->resource->getConnection()->update(
            $this->resource->getTableName('vivapayments_data'),
            [
                'order_state' => $state,
                'polling_active' => 0,
                'polling_stopped_at' => gmdate('Y-m-d H:i:s'),
                'stop_reason' => $reason,
                'response_data' => !empty($response) ? json_encode($response, JSON_UNESCAPED_SLASHES) : null,
            ],
            ['id = ?' => $id]
        );
    }

    public function setState(int $id, string $state): void
    {
        $this->resource->getConnection()->update(
            $this->resource->getTableName('vivapayments_data'),
            ['order_state' => $state], ['id = ?' => $id]
        );
    }

    public function expireDue(): int
    {
        return $this->resource->getConnection()->update(
            $this->resource->getTableName('vivapayments_data'),
            [
                'order_state' => new \Zend_Db_Expr("CASE WHEN order_state = 'unsuccessful_retrying' THEN 'unsuccessful' WHEN order_state = 'verification_error_retrying' THEN 'verification_error' ELSE 'expired' END"),
                'polling_active' => 0,
                'polling_stopped_at' => gmdate('Y-m-d H:i:s'), 'stop_reason' => 'payment_timeout',
            ],
            'polling_active = 1 AND expires_at <= UTC_TIMESTAMP()'
        );
    }

    public function recordTransaction(int $attemptId, string $kind, array $transaction, ?string $parentId = null): void
    {
        $transaction = $this->sanitize($transaction);
        $transactionId = trim((string) ($transaction['TransactionId'] ?? ''));
        if ($transactionId === '') {
            return;
        }
        $connection = $this->resource->getConnection();
        $connection->insertOnDuplicate(
            $this->resource->getTableName('vivapayments_transaction'),
            [
                'attempt_id' => $attemptId,
                'transaction_id' => $transactionId,
                'parent_transaction_id' => $parentId,
                'transaction_kind' => $kind,
                'status_id' => (string) ($transaction['StatusId'] ?? ''),
                'transaction_type_id' => isset($transaction['TransactionTypeId']) ? (int) $transaction['TransactionTypeId'] : null,
                'amount' => isset($transaction['Amount']) ? (float) $transaction['Amount'] : null,
                'currency_code' => isset($transaction['CurrencyCode']) ? (int) $transaction['CurrencyCode'] : null,
                'response_data' => json_encode($transaction, JSON_UNESCAPED_SLASHES),
                'created_at' => gmdate('Y-m-d H:i:s'),
            ],
            ['status_id', 'transaction_type_id', 'amount', 'currency_code', 'response_data']
        );
    }

    public function getTransactions(int $attemptId): array
    {
        $connection = $this->resource->getConnection();
        return $connection->fetchAll(
            $connection->select()->from($this->resource->getTableName('vivapayments_transaction'))
                ->where('attempt_id = ?', $attemptId)->order('id ASC')
        );
    }

    /** Serialize callback/worker processing for the same attempt across PHP processes. */
    public function withLock(int $attemptId, callable $operation)
    {
        $connection = $this->resource->getConnection();
        $lockName = 'ced_viva_attempt_' . $attemptId;
        $acquired = (int) $connection->fetchOne('SELECT GET_LOCK(?, 10)', [$lockName]);
        if ($acquired !== 1) {
            throw new \RuntimeException('The Viva payment attempt is currently being processed.');
        }
        try { return $operation(); }
        finally { $connection->fetchOne('SELECT RELEASE_LOCK(?)', [$lockName]); }
    }

    /** Never persist credentials, CVV, tokens or an unmasked PAN from a gateway response. */
    private function sanitize(array $data): array
    {
        foreach ($data as $key => $value) {
            $normalized = strtolower((string) $key);
            if (preg_match('/token|cvv|cvc|password|api.?key/', $normalized)) {
                unset($data[$key]);
                continue;
            }
            if (is_array($value)) {
                $data[$key] = $this->sanitize($value);
            } elseif (in_array($normalized, ['number', 'cardnumber', 'pan'], true)) {
                $data[$key] = preg_replace('/\d(?=\d{4})/', '*', (string) $value);
            }
        }
        return $data;
    }
}
