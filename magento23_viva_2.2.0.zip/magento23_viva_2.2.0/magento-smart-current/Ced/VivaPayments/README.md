# Viva Payments Smart Checkout for Magento

This build adds verified server-side polling, payment-attempt history and product-driven preauthorization.

## Installation / upgrade

After copying the module, run:

```bash
bin/magento module:enable Ced_VivaPayments
bin/magento setup:upgrade
bin/magento setup:di:compile
bin/magento cache:flush
```

For production mode, deploy static content according to the Magento installation's normal release process.

## Required polling worker

Magento cron runs at most once per minute and cannot guarantee a five-second interval. Run exactly one persistent worker under systemd, Supervisor, Kubernetes or another process manager:

```bash
bin/magento viva:payments:poll
```

The worker safely serializes processing by payment attempt. A once-per-minute Magento cron job is included only as a fallback. Configuration is under **Stores > Configuration > Sales > Payment Methods > Viva Wallet Smart Checkout**:

- Enable Background Polling (default Yes)
- Polling Interval in seconds (default 5)
- Payment Timeout in seconds (default 1800)

The timeout is also sent to `POST /api/orders` as `paymentTimeout`. Each attempt stores its own expiry, so later configuration changes do not alter in-flight payments.

## Preauthorization

Products include a **Viva Preauthorization** Yes/No attribute. If at least one visible basket item has Yes, the complete Viva payment order uses `isPreAuth=true`, with installments forced to 1. The flag is snapshotted onto the quote and sales order.

A successful preauthorization (`StatusId=F`, `TransactionTypeId=1`) does not create an invoice. The order view shows:

- **Capture**: opens the standard Magento invoice screen. Selected quantities determine the one allowed full or partial capture. After success, any un-invoiced quantities are cancelled and returned to stock when Magento inventory management is enabled.
- **Cancel Preauth**: releases the complete authorized amount and cancels the Magento order without an invoice or credit memo.

Refunds after capture use the capture transaction ID. Preauthorization, capture, cancellation and refund transactions remain as separate parent/child history records.

## Verification rules

Transactions are retrieved only with `GET /api/transactions/?ordercode={VivaOrderCode}`. Callback parameter `t`, when supplied, must exactly match a returned `TransactionId`; there is no fallback to the latest transaction. A successful payment also requires matching OrderCode, Magento Order Increment ID in MerchantTrns, amount, base currency and expected TransactionTypeId.

Only masked card metadata is persisted. Card tokens, CVV/CVC and unmasked card numbers are never stored by this module.
