<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Console\Command;

use Ced\VivaPayments\Service\PaymentPoller;
use Magento\Framework\App\State;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class PollPayments extends Command
{
    private PaymentPoller $poller;
    private State $state;

    public function __construct(PaymentPoller $poller, State $state)
    {
        $this->poller = $poller;
        $this->state = $state;
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->setName('viva:payments:poll')
            ->setDescription('Run the persistent Viva transaction polling worker')
            ->addOption('once', null, InputOption::VALUE_NONE, 'Process due attempts once and exit');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        try { $this->state->setAreaCode('adminhtml'); } catch (\Exception $e) { }
        do {
            $this->poller->pollDue();
            if ($input->getOption('once')) { break; }
            sleep(1);
        } while (true);
        return 0;
    }
}
