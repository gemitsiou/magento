<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Plugin\Adminhtml;

use Ced\VivaPayments\Service\AttemptManager;

class OrderViewButtons
{
    private AttemptManager $attempts;
    public function __construct(AttemptManager $attempts) { $this->attempts = $attempts; }

    public function afterSetLayout(\Magento\Sales\Block\Adminhtml\Order\View $subject, $result)
    {
        $order = $subject->getOrder();
        if (!$order || $order->getPayment()->getMethod() !== 'paymentmethod') { return $result; }
        $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId());
        if (!$attempt || empty($attempt['is_preauth']) || $attempt['order_state'] !== 'preauth_payment') {
            return $result;
        }
        $subject->removeButton('order_invoice');
        if ($order->canInvoice()) {
            $subject->addButton('viva_capture', [
                'label' => __('Capture'), 'class' => 'primary',
                'onclick' => "setLocation('" . $subject->getUrl('sales/order_invoice/start', ['order_id' => $order->getId()]) . "')",
            ]);
        }
        $subject->addButton('viva_cancel_preauth', [
            'label' => __('Cancel Preauth'), 'class' => 'delete',
            'onclick' => "deleteConfirm('" . __('Cancel the full Viva preauthorization?') . "','"
                . $subject->getUrl('vivapayments/order/cancelPreauth', ['order_id' => $order->getId()]) . "')",
        ]);
        return $result;
    }
}
