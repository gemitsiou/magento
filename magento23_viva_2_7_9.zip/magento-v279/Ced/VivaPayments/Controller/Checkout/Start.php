<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Controller\Checkout;

use Ced\VivaPayments\Model\PaymentMethod;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Message\ManagerInterface as MessageManager;
use Psr\Log\LoggerInterface;

/**
 * Initiates checkout by creating a Viva payment order and redirecting to the gateway.
 */
class Start implements HttpGetActionInterface
{
    private PaymentMethod $paymentMethod;
    private CheckoutSession $checkoutSession;
    private RedirectFactory $redirectFactory;
    private LoggerInterface $logger;
    private MessageManager $messageManager;
    private EncryptorInterface $encryptor;

    public function __construct(
        PaymentMethod $paymentMethod,
        CheckoutSession $checkoutSession,
        RedirectFactory $redirectFactory,
        LoggerInterface $logger,
        MessageManager $messageManager,
        EncryptorInterface $encryptor
    ) {
        $this->paymentMethod = $paymentMethod;
        $this->checkoutSession = $checkoutSession;
        $this->redirectFactory = $redirectFactory;
        $this->logger = $logger;
        $this->messageManager = $messageManager;
        $this->encryptor = $encryptor;
    }

    /**
     * Redirect customer to Viva Smart Checkout gateway.
     *
     * @return Redirect
     */
    public function execute(): Redirect
    {
        try {
            $order = $this->checkoutSession->getLastRealOrder();

            if (!$order || !$order->getId()) {
                $this->logger->error('VivaPayments Start: No order found in session');
                return $this->createErrorRedirect();
            }

            $redirectUrl = $this->paymentMethod->getRedirectUrl($order);
            $this->bindCallbackState($redirectUrl, $order);

            /** @var Redirect $result */
            $result = $this->redirectFactory->create();
            $result->setUrl($redirectUrl);

            return $result;
        } catch (LocalizedException $e) {
            $this->logger->error('VivaPayments Start error', [
                'message' => $e->getMessage(),
            ]);
            $this->messageManager->addErrorMessage($e->getMessage());
            return $this->createErrorRedirect();
        } catch (\Exception $e) {
            $this->logger->critical('VivaPayments Start unexpected error', [
                'exception' => $e->getMessage(),
            ]);
            $this->messageManager->addErrorMessage(
                __('Payment service is temporarily unavailable. Please try again later.')
            );
            return $this->createErrorRedirect();
        }
    }

    /**
     * Bind destructive customer-return actions to the checkout session that
     * initiated this exact Viva payment attempt. The hash protects the stored
     * state from accidental/tampered session data; the browser session itself
     * is the possession factor that an order-code-only caller does not have.
     */
    private function bindCallbackState(string $redirectUrl, \Magento\Sales\Model\Order $order): void
    {
        $query = (string) (parse_url($redirectUrl, PHP_URL_QUERY) ?: '');
        parse_str($query, $params);
        $orderCode = trim((string) ($params['Ref'] ?? ''));
        if ($orderCode === '') {
            throw new LocalizedException(__('Unable to bind the Viva payment return state.'));
        }

        $payload = $orderCode . '|' . (string) $order->getIncrementId() . '|' . (int) $order->getStoreId();
        $this->checkoutSession->setData('viva_callback_state', [
            'order_code' => $orderCode,
            'order_id' => (string) $order->getIncrementId(),
            'store_id' => (int) $order->getStoreId(),
            'signature' => $this->encryptor->getHash($payload),
        ]);
    }

    /**
     * Create a redirect back to checkout/cart on error.
     */
    private function createErrorRedirect(): Redirect
    {
        /** @var Redirect $redirect */
        $redirect = $this->redirectFactory->create();
        $redirect->setPath('checkout/cart');
        return $redirect;
    }
}