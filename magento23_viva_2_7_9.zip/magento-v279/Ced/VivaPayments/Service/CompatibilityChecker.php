<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Service;

use Magento\Framework\App\ProductMetadataInterface;

class CompatibilityChecker
{
    public const MIN_MAGENTO = '2.4.4';
    public const MAX_MAGENTO = '2.4.9';
    public const MIN_PHP_ID = 80100;
    public const MAX_PHP_ID_EXCLUSIVE = 80600;

    private ProductMetadataInterface $metadata;

    public function __construct(ProductMetadataInterface $metadata)
    {
        $this->metadata = $metadata;
    }

    public function getResult(): array
    {
        $magento = (string) $this->metadata->getVersion();
        $phpCompatible = PHP_VERSION_ID >= self::MIN_PHP_ID && PHP_VERSION_ID < self::MAX_PHP_ID_EXCLUSIVE;
        $magentoCompatible = version_compare($magento, self::MIN_MAGENTO, '>=')
            && version_compare($magento, '2.4.10', '<');
        return [
            'compatible' => $phpCompatible && $magentoCompatible,
            'magento_version' => $magento,
            'php_version' => PHP_VERSION,
            'magento_compatible' => $magentoCompatible,
            'php_compatible' => $phpCompatible,
        ];
    }

    public function getMessage(array $result): string
    {
        return sprintf(
            'Detected Magento %s and PHP %s. Ced_VivaPayments 2.7.9 supports Magento %s through %s and PHP 8.1 through 8.5.',
            $result['magento_version'], $result['php_version'], self::MIN_MAGENTO, self::MAX_MAGENTO
        );
    }
}
