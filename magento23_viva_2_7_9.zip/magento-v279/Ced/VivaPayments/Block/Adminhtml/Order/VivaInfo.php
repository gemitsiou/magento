<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Block\Adminhtml\Order;

use Ced\VivaPayments\Service\AttemptManager;
use Magento\Backend\Block\Template;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Framework\Registry;

class VivaInfo extends Template implements TabInterface
{
    private const TRANSACTION_TYPES = [
        0=>'Card Capture',1=>'Card Pre-auth',4=>'Card Refund - including MobilePay Online',
        5=>'Card Charge - including MobilePay Online',6=>'Card Charge (installments)',7=>'Card Void',
        8=>'Card Original Credit (refund, betting MCC only)',9=>'Wallet Charge',11=>'Wallet Refund',
        13=>'Card Refund Claimed',15=>'Dias',16=>'Cash',17=>'Cash Refund',18=>'Card Refund (installments)',
        19=>'Card PayOut',20=>'AliPay Charge',21=>'Alipay Refund',22=>'Card Manual Cash Disbursement',
        23=>'IDeal Charge',24=>'IDeal Refund',25=>'P24 Charge',26=>'P24 Refund',27=>'Blik Charge',
        28=>'Blik Refund',29=>'PayU Charge',30=>'PayU Refund',31=>'Card Withdrawal',32=>'Multibanco Charge',
        34=>'GiroPay Charge',35=>'GiroPay Refund',36=>'DirectPay Charge',37=>'DirectPay Refund',38=>'Eps Charge',
        39=>'Eps Refund',40=>'WeChat Pay Charge',41=>'WeChat Pay Refund',44=>'Direct Debit',
        45=>'Direct Debit Refund',46=>'Direct Debit Refund Claimed',48=>'PayPal Charge',49=>'PayPal Refund',
        50=>'Trustly Charge',51=>'Trustly Refund',52=>'Klarna Charge',53=>'Klarna Refund',
        54=>'MB WAY Charge (SibsPagamentosWayId)',55=>'MB WAY Refund (SibsPagamentosWayId)',
        56=>'SibsPagamentosReference Charge',57=>'SibsPagamentosReference Refund',60=>'Iris',61=>'Iris Refund',
        62=>'PaymentInitiation Charge',63=>'PaymentInitiation Refund',64=>'Bancomat Pay Charge',
        65=>'Bancomat Pay Refund',66=>'Tbi Charge',67=>'Tbi Refund',68=>'Pay On Delivery Charge',
        69=>'Card Verification',70=>'Swish Charge',71=>'Swish Refund',72=>'Blik Charge',73=>'Blik Refund',
        74=>'Bluecode Charge',75=>'Bluecode Refund',76=>'GiroPay Charge',77=>'GiroPay Refund',
        78=>'SatisPay Charge',79=>'SatisPay Refund',80=>'Klarna Pre-auth',81=>'Klarna Capture',
        82=>'Klarna Void',83=>'Refund Claimed Klarna',84=>'Iris Void',85=>'Multibanco Refund',
        86=>'Blik Direct Void',87=>'Multibanco Void',88=>'Wero Charge',89=>'Wero Refund',
        90=>'Refund Claimed Wero',91=>'Wero Void',
    ];
    private const DIGITAL_WALLETS = [
        2=>'Apple Pay',3=>'Google Pay',4=>'Samsung Pay',6=>'MobilePay Online',7=>'Mastercard Click to Pay',
    ];
    private const CURRENCIES = [
        203 => ['CZK', 'Czech Koruna'],
        208 => ['DKK', 'Danish Krone'],
        978 => ['EUR', 'Euro'],
        826 => ['GBP', 'Pound Sterling'],
        348 => ['HUF', 'Hungarian Forint'],
        985 => ['PLN', 'Polish Zloty'],
        946 => ['RON', 'Romanian Leu'],
        752 => ['SEK', 'Swedish Krona'],
    ];

    private Registry $registry;
    private AttemptManager $attempts;
    private \Ced\VivaPayments\Service\OperationJournal $operations;

    public function __construct(Template\Context $context, Registry $registry, AttemptManager $attempts, \Ced\VivaPayments\Service\OperationJournal $operations, array $data = [])
    {
        parent::__construct($context, $data);
        $this->registry = $registry;
        $this->attempts = $attempts;
        $this->operations = $operations;
    }

    public function getAttempts(): array
    {
        $order = $this->registry->registry('current_order');
        if (!$order || !$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') { return []; }
        return $this->attempts->getByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
    }

    public function getOperations(): array
    {
        $order = $this->registry->registry('current_order');
        if (!$order) { return []; }
        return $this->operations->getByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
    }

    public function prettyJson($value): string
    {
        if ($value === null || $value === '') { return '–'; }
        $decoded = json_decode((string) $value, true);
        return json_last_error() === JSON_ERROR_NONE ? (string) json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) : (string) $value;
    }

    public function getTabLabel() { return __('Viva Payment Information'); }
    public function getTabTitle() { return __('Viva Payment Information'); }
    public function canShowTab(): bool { return $this->getAttempts() !== []; }
    public function isHidden(): bool { return false; }

    public function getStatusLabel(string $state): string
    {
        $labels = [
            'pending'=>'Pending','unsuccessful_retrying'=>'Unsuccessful - Retrying','paid'=>'Success',
            'failed'=>'Failed','unsuccessful'=>'Failed','cancelled'=>'Cancelled','expired'=>'Expired',
            'verification_error_retrying'=>'Verification Error - Retrying','verification_error'=>'Verification Error',
            'preauth_payment'=>'Preauth Payment','preauth_captured'=>'Preauth Captured',
            'preauth_cancelled'=>'Preauth Cancelled','partially_refunded'=>'Partially Refunded','refunded'=>'Refunded',
        ];
        return $labels[$state] ?? ucwords(str_replace('_', ' ', $state));
    }

    public function getTransactions(int $attemptId, ?int $merchantCurrencyCode = null): array
    {
        $rows = $this->attempts->getTransactions($attemptId);
        foreach ($rows as &$row) {
            $raw = json_decode((string) $row['response_data'], true) ?: [];
            $typeId = $row['transaction_type_id'] !== null ? (int) $row['transaction_type_id'] : null;
            $row['groups'] = ['Transaction Summary'=>[
                'TransactionId'=>(string) $row['transaction_id'],
                'Parent TransactionId'=>$this->display($row['parent_transaction_id'] ?? null),
                'StatusId'=>$this->display($row['status_id'] ?? null),
                'Viva Status'=>$this->getVivaStatusDescription((string) ($row['status_id'] ?? '')),
                'TransactionTypeId'=>$this->transactionTypeLabel($typeId),
                'Amount'=>$this->display($row['amount'] ?? null),
                'CurrencyCode'=>$this->currencyLabel($row['currency_code'] ?? null),
            ]];
            $root = [];
            foreach ($raw as $key=>$value) {
                if (is_array($value)) {
                    $row['groups'][(string) $key] = $this->flattenObject($value, '', (string) $key);
                } elseif (!in_array($key, ['TransactionId','StatusId','Amount','CurrencyCode'], true)) {
                    $root[(string) $key] = $this->formatField((string) $key, $value);
                }
            }
            $root['Surcharge'] = (isset($raw['SurchargeAmount']) && (float) $raw['SurchargeAmount'] > 0) ? 'True' : 'False';
            $originalCurrency = $raw['OriginalCurrencyCode'] ?? null;
            $root['Customer selected DCC currency'] = $originalCurrency === null || $originalCurrency === ''
                ? '–' : ((int) $originalCurrency !== (int) $merchantCurrencyCode ? 'Yes' : 'No');
            if ($root) { $row['groups'] = ['Transaction Details'=>$root] + $row['groups']; }
        }
        return $rows;
    }

    public function getVivaStatusDescription(string $status): string
    {
        return ['F'=>'Payment successful','E'=>'Payment unsuccessful','A'=>'Payment pending',
            'R'=>'Fully or partially refunded','X'=>'Cancelled by merchant'][strtoupper($status)] ?? 'Unknown';
    }

    private function flattenObject(array $data, string $prefix, string $group): array
    {
        if ($data === []) { return ['Value'=>'–']; }
        $result = [];
        foreach ($data as $key=>$value) {
            $path = $prefix === '' ? (string) $key : $prefix . '.' . $key;
            if (is_array($value)) { $result += $this->flattenObject($value, $path, $group); }
            else { $result[$path] = $this->formatField($group . '.' . $path, $value); }
        }
        return $result ?: ['Value'=>'–'];
    }

    private function formatField(string $path, $value): string
    {
        if (substr($path, -17) === 'TransactionTypeId') {
            return $this->transactionTypeLabel($value === null ? null : (int) $value);
        }
        if (substr($path, -15) === 'DigitalWalletId') {
            if ($value === null || $value === '') { return '–'; }
            $id = (int) $value;
            return $id . ' (' . (self::DIGITAL_WALLETS[$id] ?? 'Unknown digital wallet') . ')';
        }
        if (substr($path, -12) === 'CurrencyCode') { return $this->currencyLabel($value); }
        return $this->display($value);
    }

    private function transactionTypeLabel(?int $id): string
    {
        return $id === null ? '–' : $id . ' (' . (self::TRANSACTION_TYPES[$id] ?? 'Unknown transaction type') . ')';
    }

    private function currencyLabel($value): string
    {
        if ($value === null || $value === '') { return '–'; }
        $numeric = (int) $value;
        $currency = self::CURRENCIES[$numeric] ?? null;
        return $currency ? $numeric . ' (' . $currency[0] . ' - ' . $currency[1] . ')' : (string) $numeric;
    }

    private function display($value): string
    {
        if ($value === null || $value === '') { return '–'; }
        if (is_bool($value)) { return $value ? 'True' : 'False'; }
        return (string) $value;
    }
}
