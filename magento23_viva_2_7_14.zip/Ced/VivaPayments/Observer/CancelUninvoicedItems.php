<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Observer;

use Ced\VivaPayments\Service\AttemptManager;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

/** After the one allowed capture, cancel all un-invoiced quantities and return them to stock. */
class CancelUninvoicedItems implements ObserverInterface
{
    private AttemptManager $attempts;
    private OrderRepositoryInterface $orders;
    public function __construct(AttemptManager $attempts, OrderRepositoryInterface $orders)
    { $this->attempts = $attempts; $this->orders = $orders; }

    public function execute(Observer $observer): void
    {
        $invoice = $observer->getEvent()->getInvoice();
        if (!$invoice || !$invoice->getOrder()) { return; }
        $order = $invoice->getOrder();
        $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
        if (!$attempt || $attempt['order_state'] !== 'preauth_captured') { return; }
        $cancelled = false;
        foreach ($order->getAllItems() as $item) {
            if ((float) $item->getQtyToCancel() > 0) {
                // Magento's item cancel event restores the salable quantity for managed-stock products.
                $item->cancel();
                $cancelled = true;
            }
        }
        if ($cancelled) {
            $order->addStatusHistoryComment(
                __('Un-invoiced quantities were cancelled after partial Viva capture and returned to stock where inventory management is enabled.')
            );
            $this->orders->save($order);
        }
    }
}
