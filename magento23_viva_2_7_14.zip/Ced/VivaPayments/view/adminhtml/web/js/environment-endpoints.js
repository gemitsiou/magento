require(['domReady!'], function () { 'use strict';
 var env=document.getElementById('payment_paymentmethod_environment'); if(!env){return;}
 var ids={order:'payment_paymentmethod_order_url',gateway:'payment_paymentmethod_cgi_url',tx:'payment_paymentmethod_transaction_url'};
 var presets={demo:{order:'https://demo.vivapayments.com/api/orders',gateway:'https://demo.vivapayments.com/web/checkout?ref={OrderCode}',tx:'https://demo.vivapayments.com/api/transactions/'},production:{order:'https://www.vivapayments.com/api/orders',gateway:'https://www.vivapayments.com/web/checkout?ref={OrderCode}',tx:'https://www.vivapayments.com/api/transactions/'}};
 env.addEventListener('change',function(){var p=presets[env.value];if(!p){return;} Object.keys(ids).forEach(function(k){var f=document.getElementById(ids[k]);if(f){f.value=p[k];f.dispatchEvent(new Event('change',{bubbles:true}));}});});
});
