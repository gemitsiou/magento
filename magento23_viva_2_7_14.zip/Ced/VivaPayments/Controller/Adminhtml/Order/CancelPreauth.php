<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Controller\Adminhtml\Order;

use Ced\VivaPayments\Service\AttemptManager;
use Ced\VivaPayments\Service\VivaApiClient;
use Magento\Backend\App\Action;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;

class CancelPreauth extends Action implements HttpPostActionInterface
{
    public const ADMIN_RESOURCE = 'Ced_VivaPayments::cancel_preauth';
    private OrderRepositoryInterface $orders;
    private AttemptManager $attempts;
    private VivaApiClient $api;
    private \Ced\VivaPayments\Service\OperationJournal $operations;

    public function __construct(
        Action\Context $context, OrderRepositoryInterface $orders,
        AttemptManager $attempts, VivaApiClient $api, \Ced\VivaPayments\Service\OperationJournal $operations
    ) { parent::__construct($context); $this->orders = $orders; $this->attempts = $attempts; $this->api = $api; $this->operations = $operations; }

    public function execute(): Redirect
    {
        $result = $this->resultRedirectFactory->create();
        $orderId = (int) $this->getRequest()->getParam('order_id');
        try {
            $order = $this->orders->get($orderId);
            $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
            if (!$attempt || empty($attempt['is_preauth']) || $attempt['order_state'] !== 'preauth_payment') {
                throw new \Magento\Framework\Exception\LocalizedException(__('No open Viva preauthorization exists.'));
            }
            $this->attempts->withLock(
                (int) $attempt['id'],
                function () use ($order, $attempt): void {
                    // Re-check state inside lock — may have been captured or cancelled concurrently
                    $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
                    if (!$fresh || $fresh['order_state'] !== 'preauth_payment') {
                        throw new \Magento\Framework\Exception\LocalizedException(
                            __('This preauthorization has already been captured or cancelled.')
                        );
                    }
                    $preauth = null;
                    foreach ($this->attempts->getTransactions((int) $fresh['id']) as $transaction) {
                        if ($transaction['transaction_kind'] === 'preauthorization') { $preauth = $transaction; break; }
                    }
                    if (!$preauth) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('Original preauthorization not found.'));
                    }
                    $operationKey = hash('sha256', 'cancel_preauth|' . (int) $order->getStoreId() . '|' . (int) $fresh['id'] . '|' . (string) $preauth['transaction_id']);
                    $journal = $this->operations->begin($operationKey, 'cancel_preauth', (int) $order->getStoreId(), (string) $order->getIncrementId(), (int) $fresh['id'], ['parent_transaction_id'=>(string)$preauth['transaction_id']]);
                    if (empty($journal['_created']) && in_array((string) ($journal['status'] ?? ''), ['pending','remote_success','reconciliation_required'], true)) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('A previous Viva preauthorization cancellation has an uncertain or uncommitted result. Reconcile it before retrying.'));
                    }
                    try {
                    $response = $this->api->cancelPreauthorization((string) $preauth['transaction_id'], [
                        'amount' => (int) $fresh['amount_cents'],
                        'sourceCode' => (string) $fresh['source_code'],
                        'merchantTrns' => (string) $order->getIncrementId(),
                        'customerTrns' => 'Cancel Preauthorization for Order ID ' . (string) $order->getIncrementId(),
                        'currencyCode' => (int) $fresh['currency_code'],
                    ], (int) $order->getStoreId(), (string) $order->getIncrementId(), (string) $fresh['ordercode']);
                    $this->operations->update($operationKey, 'remote_success', (array) $response, (string) ($response['TransactionId'] ?? ''));
                    } catch (\Throwable $e) {
                        $this->operations->update($operationKey, 'reconciliation_required', [], null, $e->getMessage());
                        throw $e;
                    }
                    $this->attempts->recordTransaction(
                        (int) $fresh['id'], 'preauth_cancel', $response, (string) $preauth['transaction_id']
                    );
                    $this->attempts->stop((int) $fresh['id'], 'preauth_cancelled', 'administrator_cancelled', $response);
                    if ($order->canCancel()) { $order->cancel(); }
                    $order->addStatusHistoryComment(__('Viva Preauthorization Cancelled. Transaction: %1', $response['TransactionId']));
                    $this->orders->save($order);
                    $this->operations->update($operationKey, 'completed', (array) $response, (string) ($response['TransactionId'] ?? ''));
                }
            );
            $this->messageManager->addSuccessMessage(__('The Viva preauthorization was cancelled.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
        return $result->setPath('sales/order/view', ['order_id' => $orderId]);
    }
}
