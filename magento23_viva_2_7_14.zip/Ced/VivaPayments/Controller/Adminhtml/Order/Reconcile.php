<?php
declare(strict_types=1);
namespace Ced\VivaPayments\Controller\Adminhtml\Order;

use Ced\VivaPayments\Service\AttemptManager;
use Ced\VivaPayments\Service\OperationJournal;
use Ced\VivaPayments\Service\VivaApiClient;
use Magento\Backend\App\Action;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Sales\Api\OrderRepositoryInterface;

/** Read-only reconciliation check. This controller never retries a financial operation. */
class Reconcile extends Action implements HttpPostActionInterface
{
    public const ADMIN_RESOURCE = 'Ced_VivaPayments::reconcile';
    public function __construct(Action\Context $context, private OrderRepositoryInterface $orders, private AttemptManager $attempts, private OperationJournal $operations, private VivaApiClient $api) { parent::__construct($context); }
    public function execute(): Redirect
    {
        $result = $this->resultRedirectFactory->create();
        $orderId = (int)$this->getRequest()->getParam('order_id');
        $operationId = (int)$this->getRequest()->getParam('operation_id');
        try {
            $order = $this->orders->get($orderId);
            $op = $this->operations->getById($operationId);
            if (!$op || (string)$op['order_id'] !== (string)$order->getIncrementId() || (int)$op['store_id'] !== (int)$order->getStoreId()) {
                throw new \Magento\Framework\Exception\LocalizedException(__('The Viva operation does not belong to this order.'));
            }
            if (!in_array((string)$op['status'], ['pending','remote_success','reconciliation_required'], true)) {
                throw new \Magento\Framework\Exception\LocalizedException(__('This operation does not require reconciliation.'));
            }
            $attempt = !empty($op['attempt_id']) ? $this->attempts->getById((int)$op['attempt_id']) : $this->attempts->getLatestByOrder((string)$order->getIncrementId(), (int)$order->getStoreId());
            if (!$attempt) {
                $this->operations->recordRecheck($operationId, ['resolved'=>false,'reason'=>'No local payment attempt exists; no financial retry was performed.']);
                throw new \Magento\Framework\Exception\LocalizedException(__('Recheck completed but no local payment attempt exists. The operation remains unresolved.'));
            }
            $remoteId = trim((string)($op['remote_transaction_id'] ?? ''));
            $expected = [
                'order_code'=>(string)$attempt['ordercode'], 'merchant_trns'=>(string)$attempt['order_id'],
                'amount_cents'=>(int)$attempt['amount_cents'], 'currency_code'=>(int)$attempt['currency_code']
            ];
            $check = $this->api->verifyTransaction((string)$attempt['ordercode'], $remoteId !== '' ? $remoteId : null, (int)$order->getStoreId(), $expected, 'Admin Reconciliation');
            $evidence = ['resolved'=>false,'operation_type'=>(string)$op['operation_type'],'known_remote_id'=>$remoteId ?: null,'verification'=>$check,'note'=>'Read-only check only. No Capture, Refund, Cancel or Create Order retry was sent.'];
            if ($remoteId !== '' && !empty($check['verified']) && hash_equals($remoteId, (string)($check['transaction_id'] ?? ''))) {
                $evidence['resolved'] = true;
                $evidence['resolution'] = 'Known remote transaction was confirmed by exact TransactionId. Local operation status was intentionally not auto-committed.';
            }
            $this->operations->recordRecheck($operationId, $evidence);
            $this->messageManager->addSuccessMessage($evidence['resolved'] ? __('Viva recheck confirmed the known remote transaction. Review the reconciliation evidence before any manual action.') : __('Viva recheck completed. The result is still not conclusive, so the operation remains blocked from automatic retry.'));
        } catch (\Exception $e) { $this->messageManager->addErrorMessage($e->getMessage()); }
        return $result->setPath('sales/order/view', ['order_id'=>$orderId]);
    }
}
