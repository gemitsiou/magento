<?php
declare(strict_types=1);
namespace Ced\VivaPayments\Service;

use Magento\Framework\App\ResourceConnection;

/** Durable guard for non-idempotent remote financial operations. */
class OperationJournal
{
    private ResourceConnection $resource;
    public function __construct(ResourceConnection $resource) { $this->resource = $resource; }

    public function begin(string $key, string $type, int $storeId, string $orderId, ?int $attemptId, array $context = []): array
    {
        $c = $this->resource->getConnection(); $t = $this->resource->getTableName('vivapayments_operation');
        $existing = $c->fetchRow($c->select()->from($t)->where('operation_key = ?', $key)->limit(1));
        if ($existing) { $existing['_created'] = false; return $existing; }
        $now = gmdate('Y-m-d H:i:s');
        $c->insert($t, ['store_id'=>$storeId,'order_id'=>$orderId,'attempt_id'=>$attemptId,'operation_key'=>$key,'operation_type'=>$type,'status'=>'pending','context_data'=>json_encode($context, JSON_UNESCAPED_SLASHES),'created_at'=>$now,'updated_at'=>$now]);
        $row = $c->fetchRow($c->select()->from($t)->where('operation_key = ?', $key)->limit(1)) ?: []; $row['_created'] = true; return $row;
    }
    public function update(string $key, string $status, array $response = [], ?string $remoteId = null, ?string $error = null): void
    {
        $this->resource->getConnection()->update($this->resource->getTableName('vivapayments_operation'), ['status'=>$status,'remote_transaction_id'=>$remoteId,'response_data'=>$response ? json_encode($response, JSON_UNESCAPED_SLASHES) : null,'error_message'=>$error,'updated_at'=>gmdate('Y-m-d H:i:s')], ['operation_key = ?'=>$key]);
    }
    public function getById(int $id): ?array
    {
        $c = $this->resource->getConnection();
        $row = $c->fetchRow($c->select()->from($this->resource->getTableName('vivapayments_operation'))->where('id = ?', $id)->limit(1));
        return $row ?: null;
    }

    /** Persist read-only reconciliation evidence without changing the financial-operation status. */
    public function recordRecheck(int $id, array $evidence): void
    {
        $this->resource->getConnection()->update(
            $this->resource->getTableName('vivapayments_operation'),
            [
                'reconciliation_checked_at' => gmdate('Y-m-d H:i:s'),
                'reconciliation_data' => json_encode($evidence, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                'updated_at' => gmdate('Y-m-d H:i:s'),
            ],
            ['id = ?' => $id]
        );
    }

    public function getByOrder(string $orderId, int $storeId): array
    {
        $c=$this->resource->getConnection(); return $c->fetchAll($c->select()->from($this->resource->getTableName('vivapayments_operation'))->where('order_id = ?',$orderId)->where('store_id = ?',$storeId)->order('id DESC'));
    }
}
