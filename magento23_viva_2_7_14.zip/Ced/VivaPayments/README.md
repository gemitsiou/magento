# Viva.com Smart Checkout for Magento

**Module version: 2.7.14**

Redirect-based Viva.com Smart Checkout integration with server-side payment verification, background polling, preauthorization/capture/refund support, concurrency protection, reconciliation tooling and detailed Admin diagnostics.

## Compatibility

- Magento Open Source 2.4.4 through 2.4.9
- PHP 8.1 through 8.5, using the PHP version supported by the installed Magento release
- Module code: `Ced_VivaPayments`
- Canonical version: `Ced\VivaPayments\Version::VERSION`

Run `php bin/magento viva:compatibility:check` before upgrades where available.

## Installation / upgrade

Back up the current module and database, copy the release to `app/code/Ced/VivaPayments`, then run from Magento root:

```bash
bin/magento maintenance:enable
bin/magento module:enable Ced_VivaPayments --clear-static-content
bin/magento setup:upgrade
bin/magento setup:di:compile
bin/magento setup:static-content:deploy -f
bin/magento cache:clean
bin/magento cache:flush
bin/magento maintenance:disable
```

Verify:

```bash
bin/magento module:status Ced_VivaPayments
```

The Admin footer appends `Viva.com Plugin Version 2.7.14` to the Magento version display.

## Configuration scope

Configuration is under **Stores > Configuration > Sales > Payment Methods > Viva.com Smart Checkout**. Operational Viva settings are Store View aware where indicated. Runtime payment processing uses the order/store context so separate Store Views can use different polling, preauthorization, endpoint, currency and checkout settings.

### Environment and endpoint presets

**Environment**: `Demo` or `Production` (Store View scope).

Changing Environment immediately populates all three visible endpoint fields in the Admin UI. The fields remain editable after population; runtime always uses the actual saved URL fields.

Demo defaults:

- OrderCode URL: `https://demo.vivapayments.com/api/orders`
- Gateway URL: `https://demo.vivapayments.com/web/checkout?ref={OrderCode}`
- Transaction URL: `https://demo.vivapayments.com/api/transactions/`

Production defaults use the same paths with `https://www.vivapayments.com`.

All endpoint values must use HTTPS and an official `vivapayments.com` host. The Gateway URL is browser-facing; `{OrderCode}` is replaced by the Viva payment order code. It is not a server-to-server transaction API.

### Accepted Currency

Viva is configured for **one currency per Store View**, selected from:

- CZK — Czech koruna
- DKK — Danish krone
- EUR — Euro
- GBP — Pound sterling
- HUF — Hungarian forint
- PLN — Polish złoty
- RON — Romanian leu
- SEK — Swedish krona

The Magento order currency must equal the configured Viva currency for the payment method to be available. The upgrade data patch preserves an existing valid single selection and safely normalizes legacy comma-separated configuration.

### RequestLang

Create Payment Order sends the Store View locale only when it is one of Viva's supported values:

`bg-BG`, `hr-HR`, `cs-CZ`, `da-DK`, `nl-NL`, `nl-BE`, `en-GB`, `fi-FI`, `fr-BE`, `fr-FR`, `de-DE`, `el-GR`, `hu-HU`, `it-IT`, `pl-PL`, `pt-PT`, `ro-RO`, `ru-RU`, `es-ES`, `sv-SE`.

Magento underscore locales are normalized to dash form. Any unsupported locale falls back to `en-GB`.

### Checkout options

- **Preselected Payment Method**: Yes/No, default Yes, Store View scope. With multiple methods Viva is preselected only when Yes. When Viva is the only available method it is selected automatically.
- **Disable Wallet**: Yes/No, Store View scope. Sent as `DisableWallet=true|false` in Create Payment Order.
- **Preauthorize All Orders**: Yes/No, Store View scope. When enabled, all Viva orders are preauthorizations and product-level preauth flags are not evaluated.
- **Successful Transaction Order Status**: Store View scoped. Applied to successful one-off payments and successful preauthorizations.
- **Background Polling**, initial delay and polling interval are Store View scoped.

## Create Payment Order

The request is `application/x-www-form-urlencoded` and includes Amount, RequestLang, Email, phone, MaxInstallments, MerchantTrns, SourceCode, CurrencyCode, DisableCash, DisableWallet, FullName, paymentTimeout, isPreAuth and CustomerTrns.

CustomerTrns conventions:

- Create Payment Order: `Payment for Order ID {Magento increment_id}`
- Capture: `Final Charge for Order ID {Magento increment_id}`
- Refund: `Refund for Order ID {Magento increment_id}`
- Cancel Preauthorization: `Cancel Preauthorization for Order ID {Magento increment_id}`

## Checkout UX, duplicate submission and redirect recovery

The first Place Order action immediately enters a processing state, disables further Viva submission and displays a localized spinner/message:

**Processing your order...**  
**Please wait while we securely redirect you to the Viva.com payment page.**

Backend quote-level and order-level locks remain the authoritative duplicate protection. Concurrent submissions of the same Viva quote reuse the committed Magento order, and concurrent payment initialization for the same Magento order reuses the active Viva attempt/order code.

A short-lived browser-session recovery marker is created as Place Order begins. If the customer reloads during the redirect window, checkout resumes `/vivapayments/checkout/start`; the server reuses the existing order/attempt rather than intentionally creating a new Viva payment order. The marker expires after two minutes and is removed when a failed checkout becomes actionable again.

## Payment verification

Callback and polling use the same business invariants: Viva OrderCode, Magento MerchantTrns/order increment ID, amount, currency and transaction status.

When callback parameter `t` is supplied, it is authoritative: the exact TransactionId must be found and there is no fallback to another transaction. Background polling can operate without a known TransactionId; after the business invariants match, the returned Viva TransactionId is persisted.

A successful transaction requires a non-empty TransactionId and successful Viva status. Successful one-off and preauthorization flows apply the Admin-configured successful order status.

## Polling

Run exactly one persistent worker where sub-minute polling is required:

```bash
bin/magento viva:payments:poll
```

Magento cron is a fallback. Attempts persist their polling schedule in the database. Worker processing uses locks, indexed due-attempt queries, keyset batching and store-specific configuration.

Customer-facing pending verification text is:

> Your payment is being verified. Please do not submit another payment for this order.

## Preauthorization, capture and invoice editing

A successful preauthorization does not create the final capture invoice. Capture opens the Magento invoice flow.

When invoice item quantities are reduced:

- Final Shipping Fee becomes editable.
- It starts with the original shipping amount including tax.
- `.` and `,` decimal input are normalized.
- The value must be non-negative with at most two decimal places.
- Shipping tax is recalculated using the original shipping tax ratio.
- The final capture cannot exceed the original authorization.

Updating item quantities is not blocked merely because shipping has not been manually edited; the original shipping value is the default.

An invoice/basket with all quantities reduced to zero is rejected both server-side and in the Admin UI with:

> Your basket should not be empty. If you do not wish to proceed with the order, please cancel it.

## Admin Cancel Order

For an open preauthorization, **Cancel Order** is displayed beside **Capture** with the same primary/orange button treatment. It cancels the remote preauthorization before cancelling Magento.

For a pending Viva Payment Order, Cancel Order is Viva-aware and never performs local-only cancellation:

1. Acquire the payment-attempt lock.
2. Perform up to **three read-only Viva verification attempts**, with a 750ms controlled delay between attempts.
3. Each verification is separately recorded in Viva Logs as `Admin Cancel Verification #1/#2/#3`.
4. If a valid successful transaction appears, cancellation is aborted and the payment/preauthorization is synchronized to Magento.
5. If all checks cleanly show no transaction, cancel the Viva Payment Order first; only confirmed remote cancellation allows Magento cancellation.
6. If verification is technical/ambiguous, do not DELETE and do not cancel Magento. The attempt remains blocked for reconciliation and a `Cancel Decision` audit entry is recorded.

## Customer cancellation from Viva

A valid customer `cancel=1` return is session-bound. Before destructive cancellation the module verifies Viva once more so a just-completed payment wins over cancellation. After confirmed cancellation the Magento order is cancelled, the quote is restored and the customer sees:

> You chose to cancel your payment and your basket has been restored.

## Refunds and financial-operation safety

Refund and capture calls are protected by payment-attempt locks and a durable operation journal. An ambiguous remote outcome is never blindly retried. Such operations are marked for reconciliation. The Admin Recheck action is read-only and does not send Capture, Refund, Cancel Preauthorization or Create Payment Order again.

## Viva Payment Information

The Admin Order View contains **Viva Payment Information**. It shows all payment attempts newest-first, not only the latest attempt, with their associated transactions, payment type, order code, transaction/parent IDs, state/status, response objects, DCC/card/wallet information where returned, capture/refund/cancellation history and financial-operation/reconciliation evidence.

## Viva Logs

The Admin Order View contains **Viva Logs**, newest-first and paginated. Testing builds intentionally retain full diagnostic request/response information. Entries include operation, trigger, method, endpoint, HTTP status, duration, parsed/raw request and response data, query/path information, validation, errors and state transitions.

After Create Payment Order, the browser redirect is recorded as **Payment Page Redirect** with the final generated Smart Checkout URL and Viva OrderCode.

## Security and concurrency

- API key uses Magento encrypted configuration storage.
- TLS peer and hostname verification remain enabled.
- Configurable Viva endpoints are restricted to HTTPS `vivapayments.com` hosts.
- Admin financial actions are POST/form-key protected and ACL controlled.
- Customer destructive cancellation is bound to the checkout session.
- Payment attempts, callback/poller processing, quote submission and financial operations use locks/idempotency safeguards.
- Full diagnostic logs are retained intentionally for the current testing/UAT phase; review retention/redaction before production rollout.

## UAT checklist

At minimum test:

1. One-off success via callback.
2. One-off success via polling only/browser closed.
3. Preauth success via callback and polling.
4. Full and partial capture.
5. Quantity reduction with unchanged, changed and zero shipping.
6. Empty-basket rejection.
7. Full and partial refund and CustomerTrns values.
8. Preauth cancellation and CustomerTrns value.
9. Customer cancel=1 and basket restoration.
10. Pending Admin Cancel Order: payment found, clean no-transaction cancellation, and ambiguous verification/reconciliation.
11. Rapid/double Place Order and concurrent same-quote submission.
12. Browser reload during checkout redirect.
13. Preselected Payment Method Yes/No with one and multiple payment methods.
14. DisableWallet Yes/No request payload.
15. Demo/Production Environment automatic endpoint population and manual endpoint edits.
16. Each supported Accepted Currency and unsupported order currency.
17. Supported RequestLang mappings and `en-GB` fallback.
18. Viva Payment Information with multiple attempts.
19. Viva Logs including Payment Page Redirect and three Cancel Verification entries.
20. Admin footer version display.
