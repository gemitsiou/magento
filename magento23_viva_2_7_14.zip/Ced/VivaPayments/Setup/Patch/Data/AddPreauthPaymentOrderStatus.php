<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\StatusFactory;
use Magento\Sales\Model\ResourceModel\Order\Status as StatusResource;

class AddPreauthPaymentOrderStatus implements DataPatchInterface
{
    private ModuleDataSetupInterface $setup;
    private StatusFactory $statusFactory;
    private StatusResource $statusResource;

    public function __construct(
        ModuleDataSetupInterface $setup,
        StatusFactory $statusFactory,
        StatusResource $statusResource
    ) {
        $this->setup = $setup;
        $this->statusFactory = $statusFactory;
        $this->statusResource = $statusResource;
    }

    public function apply(): self
    {
        $this->setup->getConnection()->startSetup();
        $status = $this->statusFactory->create();
        $this->statusResource->load($status, 'preauth_payment');
        if (!$status->getStatus()) {
            $status->setData(['status' => 'preauth_payment', 'label' => 'Preauth Payment']);
            $this->statusResource->save($status);
        }
        $status->assignState(Order::STATE_PROCESSING, false, true);
        $this->setup->getConnection()->endSetup();
        return $this;
    }

    public static function getDependencies(): array { return []; }
    public function getAliases(): array { return []; }
}
