<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class BackfillOrderMetadata implements DataPatchInterface
{
    private ResourceConnection $resource;

    public function __construct(ResourceConnection $resource)
    {
        $this->resource = $resource;
    }

    public function apply(): self
    {
        $connection = $this->resource->getConnection();
        $attemptTable = $this->resource->getTableName('vivapayments_data');
        $transactionTable = $this->resource->getTableName('vivapayments_transaction');
        $orderTable = $this->resource->getTableName('sales_order');
        // Composite key (store_id, order_id) to avoid multistore collisions.
        $seen = [];
        $attempts = $connection->fetchAll(
            $connection->select()->from($attemptTable)->order('id DESC')
        );
        foreach ($attempts as $attempt) {
            $incrementId = (string) $attempt['order_id'];
            $storeId = (int) $attempt['store_id'];
            $compositeKey = $storeId . ':' . $incrementId;
            if (isset($seen[$compositeKey])) { continue; }
            $seen[$compositeKey] = true;
            $transactionId = $connection->fetchOne(
                $connection->select()->from($transactionTable, 'transaction_id')
                    ->where('attempt_id = ?', (int) $attempt['id'])
                    ->where('transaction_kind IN (?)', ['payment', 'preauthorization'])
                    ->order('id ASC')->limit(1)
            );
            $data = [
                'viva_payment_type' => !empty($attempt['is_preauth']) ? 'preauthorization' : 'one_off',
                'viva_order_code' => (string) $attempt['ordercode'],
                'viva_transaction_id' => $transactionId ?: null,
            ];
            if (!empty($attempt['is_preauth']) && $attempt['order_state'] === 'preauth_payment') {
                $data['state'] = 'processing';
                $data['status'] = 'preauth_payment';
            }
            $connection->update($orderTable, $data, [
                'increment_id = ?' => $incrementId,
                'store_id = ?' => $storeId,
            ]);
        }
        return $this;
    }

    public static function getDependencies(): array { return [AddPreauthPaymentOrderStatus::class]; }
    public function getAliases(): array { return []; }
}
