<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Setup\Patch\DataPatchInterface;

/**
 * Preflight cleanup: assigns unique attempt_no values per (store_id, order_id)
 * before the unique constraint VIVAPAYMENTS_DATA_ORDER_ATTEMPT_UNQ is applied.
 * Safe to run multiple times (idempotent).
 */
class DeduplicateAttemptNo implements DataPatchInterface
{
    private ResourceConnection $resource;

    public function __construct(ResourceConnection $resource)
    {
        $this->resource = $resource;
    }

    public function apply(): self
    {
        $connection = $this->resource->getConnection();
        $table = $this->resource->getTableName('vivapayments_data');

        // Find (store_id, order_id) groups that have duplicate attempt_no values
        $duplicates = $connection->fetchAll(
            "SELECT store_id, order_id FROM {$table}
             GROUP BY store_id, order_id
             HAVING COUNT(*) > 1
             ORDER BY store_id, order_id"
        );

        foreach ($duplicates as $group) {
            $rows = $connection->fetchAll(
                "SELECT id FROM {$table}
                 WHERE store_id = ? AND order_id = ?
                 ORDER BY id ASC",
                [$group['store_id'], $group['order_id']]
            );

            $attemptNo = 1;
            foreach ($rows as $row) {
                $connection->update(
                    $table,
                    ['attempt_no' => $attemptNo],
                    ['id = ?' => (int) $row['id']]
                );
                $attemptNo++;
            }
        }

        return $this;
    }

    public static function getDependencies(): array
    {
        return [BackfillOrderMetadata::class];
    }

    public function getAliases(): array
    {
        return [];
    }
}
