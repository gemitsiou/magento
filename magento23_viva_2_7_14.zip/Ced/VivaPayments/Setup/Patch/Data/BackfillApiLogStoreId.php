<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Setup\Patch\DataPatchInterface;

/**
 * Backfills store_id in vivapayments_api_log from vivapayments_data via ordercode.
 * Fixes existing log rows that were written with store_id = 0 before this column existed.
 */
class BackfillApiLogStoreId implements DataPatchInterface
{
    private ResourceConnection $resource;

    public function __construct(ResourceConnection $resource)
    {
        $this->resource = $resource;
    }

    public function apply(): self
    {
        $connection = $this->resource->getConnection();
        $logTable = $this->resource->getTableName('vivapayments_api_log');
        $dataTable = $this->resource->getTableName('vivapayments_data');

        // Update store_id in api_log by joining on ordercode
        $connection->query(
            "UPDATE {$logTable} l
             INNER JOIN {$dataTable} d ON d.ordercode = l.ordercode
             SET l.store_id = d.store_id
             WHERE l.store_id = 0 AND l.ordercode IS NOT NULL AND l.ordercode != ''"
        );

        // For logs with no ordercode, match via (order_id, store_id) from the most recent attempt.
        // Use a deterministic subquery: pick the attempt with the highest id per (store_id, order_id).
        $connection->query(
            "UPDATE {$logTable} l
             INNER JOIN (
                 SELECT d1.order_id, d1.store_id
                 FROM {$dataTable} d1
                 INNER JOIN (
                     SELECT order_id, MAX(id) AS max_id
                     FROM {$dataTable}
                     GROUP BY order_id
                 ) d2 ON d1.id = d2.max_id
             ) d ON d.order_id = l.order_id
             SET l.store_id = d.store_id
             WHERE l.store_id = 0 AND (l.ordercode IS NULL OR l.ordercode = '')"
        );

        return $this;
    }

    public static function getDependencies(): array
    {
        return [];
    }

    public function getAliases(): array
    {
        return [];
    }
}
