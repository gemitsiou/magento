<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Block\Adminhtml\Order;

use Ced\VivaPayments\Service\AttemptManager;
use Magento\Backend\Block\Template;
use Magento\Framework\Registry;

class PaymentControls extends Template
{
    private Registry $registry;
    private AttemptManager $attempts;

    public function __construct(
        Template\Context $context,
        Registry $registry,
        AttemptManager $attempts,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->registry = $registry;
        $this->attempts = $attempts;
    }

    public function isVivaOrder(): bool
    {
        $order = $this->getCurrentOrder();
        return $order && $order->getPayment() && $order->getPayment()->getMethod() === 'paymentmethod';
    }

    public function isOpenPreauthorization(): bool
    {
        $order = $this->getCurrentOrder();
        if (!$order || !$this->isVivaOrder()) {
            return false;
        }
        $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
        return (bool) ($attempt && !empty($attempt['is_preauth']) && $attempt['order_state'] === 'preauth_payment');
    }

    public function getCaptureConfig(): array
    {
        $order = $this->getCurrentOrder();
        $attempt = $order ? $this->attempts->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId()) : null;
        if (!$order || !$attempt) { return []; }
        $shipping = (float) ($order->getBaseShippingInclTax()
            ?: ((float) $order->getBaseShippingAmount() + (float) $order->getBaseShippingTaxAmount()));
        $items = [];
        foreach ($order->getAllItems() as $item) {
            if ((float) $item->getQtyToInvoice() > 0) {
                $items[(string) $item->getId()] = (float) $item->getQtyToInvoice();
            }
        }
        return [
            'originalShippingFee' => round($shipping, 2),
            'authorizedAmount' => round(((int) $attempt['amount_cents']) / 100, 2),
            'currency' => (string) $order->getBaseCurrencyCode(),
            'displayRate' => (float) $order->getBaseToOrderRate() > 0
                ? (float) $order->getBaseToOrderRate() : 1.0,
            'itemQuantities' => $items,
        ];
    }

    private function getCurrentOrder()
    {
        $order = $this->registry->registry('current_order');
        if ($order) {
            return $order;
        }
        $invoice = $this->registry->registry('current_invoice');
        if ($invoice && $invoice->getOrder()) {
            return $invoice->getOrder();
        }
        $creditmemo = $this->registry->registry('current_creditmemo');
        return $creditmemo && $creditmemo->getOrder() ? $creditmemo->getOrder() : null;
    }
}
