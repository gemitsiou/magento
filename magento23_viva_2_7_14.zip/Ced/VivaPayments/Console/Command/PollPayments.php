<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Console\Command;

use Ced\VivaPayments\Service\PaymentPoller;
use Magento\Framework\App\Config\ReinitableConfigInterface;
use Magento\Framework\App\State;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class PollPayments extends Command
{
    private PaymentPoller $poller;
    private State $state;
    private ReinitableConfigInterface $config;
    private bool $stopRequested = false;

    public function __construct(
        PaymentPoller $poller,
        State $state,
        ReinitableConfigInterface $config
    ) {
        $this->poller = $poller;
        $this->state = $state;
        $this->config = $config;
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->setName('viva:payments:poll')
            ->setDescription('Run the persistent Viva transaction polling worker')
            ->addOption('once', null, InputOption::VALUE_NONE, 'Process due attempts once and exit')
            ->addOption('sleep', null, InputOption::VALUE_REQUIRED, 'Worker database check interval in seconds', '5')
            ->addOption('max-runtime', null, InputOption::VALUE_REQUIRED, 'Graceful recycle time in seconds', '3600');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        try {
            $this->state->setAreaCode('adminhtml');
        } catch (\Exception $e) {
            // Area code can already be set by another bootstrap integration.
        }

        $once = (bool) $input->getOption('once');
        $sleepSeconds = max(1, (int) $input->getOption('sleep'));
        $maxRuntime = max(60, (int) $input->getOption('max-runtime'));
        $startedAt = time();
        $lastConfigReload = 0;
        $schedulingSignature = '';
        $this->registerSignalHandlers();

        do {
            $now = time();
            if ($lastConfigReload === 0 || ($now - $lastConfigReload) >= 30) {
                // Long-running Magento processes otherwise retain stale Admin configuration.
                $this->config->reinit();
                $newSignature = $this->poller->getSchedulingConfigSignature();
                if ($schedulingSignature !== '' && $newSignature !== $schedulingSignature) {
                    $this->poller->refreshSchedulesFromConfiguration();
                }
                $schedulingSignature = $newSignature;
                $lastConfigReload = $now;
            }
            $this->poller->pollDue();
            if ($once || $this->stopRequested || ($now - $startedAt) >= $maxRuntime) {
                break;
            }
            sleep($sleepSeconds);
            if (function_exists('pcntl_signal_dispatch')) {
                pcntl_signal_dispatch();
            }
        } while (true);

        return 0;
    }

    private function registerSignalHandlers(): void
    {
        if (!function_exists('pcntl_signal')) {
            return;
        }
        pcntl_signal(SIGTERM, function (): void { $this->stopRequested = true; });
        pcntl_signal(SIGINT, function (): void { $this->stopRequested = true; });
    }
}
