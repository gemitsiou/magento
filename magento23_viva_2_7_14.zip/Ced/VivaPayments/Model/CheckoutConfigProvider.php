<?php
declare(strict_types=1);
namespace Ced\VivaPayments\Model;
use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
class CheckoutConfigProvider implements ConfigProviderInterface { public function __construct(private ScopeConfigInterface $scopeConfig){} public function getConfig(): array { return ['payment'=>['vivapayments'=>['preselected'=>(bool)$this->scopeConfig->getValue('payment/paymentmethod/preselected_payment_method',ScopeInterface::SCOPE_STORE)]]]; } }
