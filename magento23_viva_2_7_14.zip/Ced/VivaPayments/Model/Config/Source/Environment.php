<?php
declare(strict_types=1);
namespace Ced\VivaPayments\Model\Config\Source;
use Magento\Framework\Data\OptionSourceInterface;
class Environment implements OptionSourceInterface { public function toOptionArray(): array { return [['value'=>'demo','label'=>__('Demo')],['value'=>'production','label'=>__('Production')]]; } }
