<?php
declare(strict_types=1);
namespace Ced\VivaPayments\Model\Config\Source;
use Magento\Framework\Data\OptionSourceInterface;
class VivaCurrency implements OptionSourceInterface { public function toOptionArray(): array { return [
['value'=>'CZK','label'=>__('CZK - Czech koruna')],['value'=>'DKK','label'=>__('DKK - Danish krone')],['value'=>'EUR','label'=>__('EUR - Euro')],['value'=>'GBP','label'=>__('GBP - Pound sterling')],['value'=>'HUF','label'=>__('HUF - Hungarian forint')],['value'=>'PLN','label'=>__('PLN - Polish zloty')],['value'=>'RON','label'=>__('RON - Romanian leu')],['value'=>'SEK','label'=>__('SEK - Swedish krona')]]; } }
