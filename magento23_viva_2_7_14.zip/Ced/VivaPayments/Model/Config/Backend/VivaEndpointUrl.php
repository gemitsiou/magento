<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Model\Config\Backend;

use Magento\Framework\App\Config\Value;
use Magento\Framework\Exception\LocalizedException;

/**
 * Validates that Viva API endpoint URLs use HTTPS and an official Viva Wallet domain.
 * Prevents credential exfiltration via SSRF attacks.
 */
class VivaEndpointUrl extends Value
{
    private const ALLOWED_BASE_DOMAINS = [
        'vivapayments.com',
    ];

    public function beforeSave(): self
    {
        $value = trim((string) $this->getValue());

        if ($value === '') {
            return parent::beforeSave();
        }

        $parsed = parse_url($value);

        if (($parsed['scheme'] ?? '') !== 'https') {
            throw new LocalizedException(
                __('Viva API endpoints must use HTTPS.')
            );
        }

        $host = strtolower($parsed['host'] ?? '');
        if (!$this->isAllowedHost($host)) {
            throw new LocalizedException(
                __('Viva API endpoints must use an official Viva Wallet domain (vivapayments.com).')
            );
        }

        return parent::beforeSave();
    }

    private function isAllowedHost(string $host): bool
    {
        foreach (self::ALLOWED_BASE_DOMAINS as $allowedDomain) {
            if ($host === $allowedDomain || str_ends_with($host, '.' . $allowedDomain)) {
                return true;
            }
        }
        return false;
    }
}
