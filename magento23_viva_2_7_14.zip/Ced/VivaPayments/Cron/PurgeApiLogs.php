<?php
declare(strict_types=1);
namespace Ced\VivaPayments\Cron;
use Ced\VivaPayments\Service\ApiLogManager;
use Magento\Framework\App\Config\ScopeConfigInterface;
class PurgeApiLogs
{
    private ApiLogManager $logs; private ScopeConfigInterface $config;
    public function __construct(ApiLogManager $logs, ScopeConfigInterface $config) { $this->logs=$logs; $this->config=$config; }
    public function execute(): void { $days=(int)$this->config->getValue('payment/paymentmethod/api_log_retention_days'); $this->logs->purgeOlderThanDays($days > 0 ? $days : 90); }
}
