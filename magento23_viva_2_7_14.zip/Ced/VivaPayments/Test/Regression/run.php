<?php
declare(strict_types=1);
$root = dirname(__DIR__, 2);
$checks = [
 'version_2714' => str_contains(file_get_contents($root.'/Version.php'), "2.7.14"),
 'gateway_checkout_template' => str_contains(file_get_contents($root.'/etc/config.xml'), '/web/checkout?ref={OrderCode}'),
 'single_currency_source' => str_contains(file_get_contents($root.'/etc/adminhtml/system.xml'), 'VivaCurrency'),
 'disable_wallet' => str_contains(file_get_contents($root.'/Service/VivaApiClient.php'), "'DisableWallet'"),
 'refund_customertrns' => str_contains(file_get_contents($root.'/Model/PaymentMethod.php'), 'Refund for Order ID'),
 'cancel_customertrns' => str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/CancelPreauth.php'), 'Cancel Preauthorization for Order ID'),
 'admin_cancel_three_checks' => str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/CancelPending.php'), 'for($i=1;$i<=3;$i++)'),
 'admin_cancel_delay' => str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/CancelPending.php'), 'usleep(750000)'),
 'environment_presets' => str_contains(file_get_contents($root.'/view/adminhtml/web/js/environment-endpoints.js'), 'production'),
 'checkout_processing_loader' => str_contains(file_get_contents($root.'/view/frontend/web/template/payment/paymentmethod.html'), 'viva-processing-spinner'),
 'checkout_reload_recovery' => str_contains(file_get_contents($root.'/view/frontend/web/js/view/payment/method-renderer/paymentmethod-method.js'), 'vivaCheckoutRedirectPending'),
 'footer_version' => str_contains(file_get_contents($root.'/Plugin/Adminhtml/FooterVersion.php'), 'afterGetMagentoVersion'),
 'payment_redirect_log' => str_contains(file_get_contents($root.'/Controller/Checkout/Start.php'), "'operation'=>'Payment Page Redirect'"),
 'empty_basket_guard' => str_contains(file_get_contents($root.'/Plugin/InvoiceServiceFinalShipping.php'), 'Your basket should not be empty'),
 'requestlang_fallback' => str_contains(file_get_contents($root.'/Model/PaymentMethod.php'), "return 'en-GB';"),
 'version' => str_contains(file_get_contents($root.'/composer.json'), '"version": "2.7.14"'),
 'explicit_version_constant' => is_file($root.'/Version.php') && str_contains(file_get_contents($root.'/Version.php'), "public const VERSION = '2.7.14'"),
 'admin_tabs_addtab_registration' => (function () use ($root): bool {
     $xml = file_get_contents($root.'/view/adminhtml/layout/sales_order_view.xml');
     return substr_count($xml, '<action method="addTab">') === 2
         && str_contains($xml, '<argument name="block" xsi:type="string">ced.vivapayments.order.info.tab</argument>')
         && str_contains($xml, '<argument name="block" xsi:type="string">ced.vivapayments.order.logs.tab</argument>');
 })(),
 'admin_vivainfo_canonical_visibility' => str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaInfo.php'), "getMethod() === 'paymentmethod'") && str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaInfo.php'), 'return $this->getAttempts() !== [];'),
 'admin_tabs_tabinterface' => str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaInfo.php'), 'implements TabInterface') && str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaLogs.php'), 'implements TabInterface'),
 'admin_tabs_not_acl_hidden' => !str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaInfo.php'), "isAllowed('Ced_VivaPayments::view_payment_info') &&") && !str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaLogs.php'), "isAllowed('Ced_VivaPayments::view_api_logs') &&"),
 'reconcile_acl' => str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), "ADMIN_RESOURCE = 'Ced_VivaPayments::reconcile'"),
 'reconcile_post' => str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'HttpPostActionInterface'),
 'no_blind_refund' => !str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'refundTransaction('),
 'no_blind_capture' => !str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'capturePreauthorization('),
 'no_blind_cancel' => !str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'cancelPreauthorization('),
 'no_blind_create' => !str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'createPaymentOrder('),
 'callback_no_transaction_fallback' => str_contains(file_get_contents($root.'/Service/VivaApiClient.php'), 'if (!empty($transactionId))') && str_contains(file_get_contents($root.'/Service/VivaApiClient.php'), 'return null;'),
 'granular_acl' => str_contains(file_get_contents($root.'/etc/acl.xml'), 'view_payment_info') && str_contains(file_get_contents($root.'/etc/acl.xml'), 'view_api_logs'),
 'quote_submit_plugin_registered' => str_contains(file_get_contents($root.'/etc/di.xml'), 'ced_vivapayments_quote_submit_idempotency'),
 'quote_submit_viva_scoped' => str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), "PAYMENT_METHOD = 'paymentmethod'"),
 'quote_submit_lock' => str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), 'ced_viva_quote_submit_') && str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), 'finally'),
 'quote_submit_existing_order_reuse' => str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), "where('quote_id = ?'") && str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), 'orderRepository->get'),
 'frontend_single_submit' => str_contains(file_get_contents($root.'/view/frontend/web/template/payment/paymentmethod.html'), "enable: (getCode() == isChecked()) && isPlaceOrderActionAllowed()"),
];
foreach ($checks as $name=>$ok) { echo ($ok?'PASS ':'FAIL ').$name.PHP_EOL; if (!$ok) exit(1); }
