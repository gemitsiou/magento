<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Plugin;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Lock\LockManagerInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\QuoteManagement;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;

/**
 * Prevent concurrent Place Order submissions of the same Viva quote from
 * creating more than one Magento order.
 *
 * Magento's frontend already suppresses normal double clicks. This backend
 * guard covers concurrent/replayed HTTP requests and multi-tab submissions.
 * It intentionally applies only to Viva.com Smart Checkout quotes.
 */
class QuoteSubmitIdempotency
{
    private const PAYMENT_METHOD = 'paymentmethod';

    public function __construct(
        private LockManagerInterface $lockManager,
        private ResourceConnection $resource,
        private OrderRepositoryInterface $orderRepository
    ) {
    }

    /**
     * Serialize QuoteManagement::submit() for a Viva quote and reuse an order
     * already committed for the same quote instead of creating a second one.
     *
     * @param QuoteManagement $subject
     * @param callable $proceed
     * @param Quote $quote
     * @param array $orderData
     * @return Order|null
     * @throws LocalizedException
     */
    public function aroundSubmit(
        QuoteManagement $subject,
        callable $proceed,
        Quote $quote,
        array $orderData = []
    ) {
        $payment = $quote->getPayment();
        if (!$payment || (string) $payment->getMethod() !== self::PAYMENT_METHOD) {
            return $proceed($quote, $orderData);
        }

        $quoteId = (int) $quote->getId();
        if ($quoteId <= 0) {
            return $proceed($quote, $orderData);
        }

        $lockName = 'ced_viva_quote_submit_' . (int) $quote->getStoreId() . '_' . $quoteId;
        if (!$this->lockManager->lock($lockName, 15)) {
            throw new LocalizedException(
                __('This checkout is already being submitted. Please wait a moment before trying again.')
            );
        }

        try {
            $existingOrderId = $this->findExistingOrderEntityId($quoteId);
            if ($existingOrderId !== null) {
                return $this->orderRepository->get($existingOrderId);
            }

            return $proceed($quote, $orderData);
        } finally {
            $this->lockManager->unlock($lockName);
        }
    }

    private function findExistingOrderEntityId(int $quoteId): ?int
    {
        $connection = $this->resource->getConnection();
        $orderTable = $this->resource->getTableName('sales_order');
        $entityId = $connection->fetchOne(
            $connection->select()
                ->from($orderTable, ['entity_id'])
                ->where('quote_id = ?', $quoteId)
                ->order('entity_id ASC')
                ->limit(1)
        );

        return $entityId === false ? null : (int) $entityId;
    }
}
