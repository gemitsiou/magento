<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Plugin;

use Ced\VivaPayments\Service\AttemptManager;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Service\InvoiceService;

class InvoiceServiceFinalShipping
{
    private RequestInterface $request;
    private AttemptManager $attempts;

    public function __construct(RequestInterface $request, AttemptManager $attempts)
    {
        $this->request = $request;
        $this->attempts = $attempts;
    }

    public function beforePrepareInvoice(InvoiceService $subject, Order $order, array $orderItemsQty = []): array
    {
        if (!$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') {
            return [$order, $orderItemsQty];
        }
        $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
        if (!$attempt || empty($attempt['is_preauth']) || $attempt['order_state'] !== 'preauth_payment') {
            return [$order, $orderItemsQty];
        }

        $itemsChanged = false;
        foreach ($order->getAllItems() as $item) {
            $available = (float) $item->getQtyToInvoice();
            if ($available <= 0) { continue; }
            $requested = array_key_exists((int) $item->getId(), $orderItemsQty)
                ? (float) $orderItemsQty[(int) $item->getId()]
                : $available;
            if (abs($requested - $available) > 0.0001) { $itemsChanged = true; break; }
        }

        $remainingQty = 0.0;
        foreach ($order->getAllItems() as $item) {
            $available = (float) $item->getQtyToInvoice();
            if ($available <= 0) { continue; }
            $requested = array_key_exists((int) $item->getId(), $orderItemsQty) ? (float) $orderItemsQty[(int) $item->getId()] : $available;
            $remainingQty += max(0.0, $requested);
        }
        if ($remainingQty <= 0.0001) {
            throw new LocalizedException(__('Your basket should not be empty. If you do not wish to proceed with the order, please cancel it.'));
        }

        $invoiceData = (array) $this->request->getParam('invoice', []);
        $rawFee = isset($invoiceData['viva_final_shipping_fee'])
            ? trim(str_replace(',', '.', (string) $invoiceData['viva_final_shipping_fee']))
            : '';
        $originalGross = (float) ($order->getBaseShippingInclTax()
            ?: ((float) $order->getBaseShippingAmount() + (float) $order->getBaseShippingTaxAmount()));

        if (!$itemsChanged) {
            if ($rawFee !== '' && abs((float) $rawFee - $originalGross) > 0.001) {
                throw new LocalizedException(__('Final Shipping Fee can be changed only when invoice item quantities are reduced.'));
            }
            return [$order, $orderItemsQty];
        }
        if ($rawFee === '') { $rawFee = number_format($originalGross, 2, '.', ''); }
        if (!preg_match('/^\d+(?:\.\d{1,2})?$/', $rawFee)) {
            throw new LocalizedException(__('Final Shipping Fee must be a non-negative number with no more than two decimal places.'));
        }

        $newGross = round((float) $rawFee, 2);
        $oldNet = (float) $order->getBaseShippingAmount();
        $oldTax = (float) $order->getBaseShippingTaxAmount();
        $taxRate = $oldNet > 0 ? $oldTax / $oldNet : 0.0;
        $newNet = $taxRate > 0 ? round($newGross / (1 + $taxRate), 2) : $newGross;
        $newTax = round($newGross - $newNet, 2);
        $rate = (float) $order->getBaseToOrderRate();
        $rate = $rate > 0 ? $rate : 1.0;

        $order->setBaseShippingAmount($newNet)
            ->setBaseShippingTaxAmount($newTax)
            ->setBaseShippingInclTax($newGross)
            ->setBaseShippingDiscountAmount(0)
            ->setShippingAmount(round($newNet * $rate, 2))
            ->setShippingTaxAmount(round($newTax * $rate, 2))
            ->setShippingInclTax(round($newGross * $rate, 2))
            ->setShippingDiscountAmount(0);

        return [$order, $orderItemsQty];
    }
}
