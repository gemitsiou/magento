<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Plugin\Adminhtml;

use Ced\VivaPayments\Service\AttemptManager;

class OrderViewButtons
{
    private AttemptManager $attempts;
    public function __construct(AttemptManager $attempts) { $this->attempts = $attempts; }

    public function afterSetLayout(\Magento\Sales\Block\Adminhtml\Order\View $subject, $result)
    {
        $order = $subject->getOrder();
        if (!$order || $order->getPayment()->getMethod() !== 'paymentmethod') { return $result; }
        $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
        if (!$attempt) { return $result; }
        if ($attempt['order_state'] === 'pending') {
            $subject->removeButton('order_cancel');
            $url=$subject->getUrl('vivapayments/order/cancelPending',['order_id'=>$order->getId()]); $key=$subject->getFormKey();
            $subject->addButton('viva_cancel_order',['label'=>__('Cancel Order'),'class'=>'primary','sort_order'=>21,'onclick'=>"if(confirm('Cancel this Viva order?')){var f=document.createElement('form');f.method='POST';f.action='".$url."';var k=document.createElement('input');k.type='hidden';k.name='form_key';k.value='".$key."';f.appendChild(k);document.body.appendChild(f);f.submit();}"]);
            return $result;
        }
        if (empty($attempt['is_preauth']) || $attempt['order_state'] !== 'preauth_payment') { return $result; }
        $subject->removeButton('order_invoice');
        $subject->removeButton('order_cancel');
        $subject->removeButton('order_ship');
        if ($order->canInvoice()) {
            $subject->addButton('viva_capture', [
                'label' => __('Capture'), 'class' => 'primary', 'sort_order' => 20,
                'onclick' => "setLocation('" . $subject->getUrl('sales/order_invoice/start', ['order_id' => $order->getId()]) . "')",
            ]);
        }
        $cancelUrl = $subject->getUrl('vivapayments/order/cancelPreauth', ['order_id' => $order->getId()]);
        $formKey = $subject->getFormKey();
        $confirmMsg = (string) __('Cancel the full Viva preauthorization?');
        $subject->addButton('viva_cancel_preauth', [
            'label' => __('Cancel Order'), 'class' => 'primary', 'sort_order' => 21,
            'onclick' => "if(confirm('" . $confirmMsg . "')){" .
                "var f=document.createElement('form');" .
                "f.method='POST';" .
                "f.action='" . $cancelUrl . "';" .
                "var k=document.createElement('input');" .
                "k.type='hidden';k.name='form_key';k.value='" . $formKey . "';" .
                "f.appendChild(k);" .
                "document.body.appendChild(f);" .
                "f.submit();}",
        ]);
        return $result;
    }
}
