<?php
declare(strict_types=1);
namespace Ced\VivaPayments\Plugin\Adminhtml;
use Ced\VivaPayments\Version;
class FooterVersion { public function afterGetMagentoVersion($subject, $result): string { return (string)$result . ' - Viva.com Plugin Version ' . Version::VERSION; } }
