# Viva.com Smart Checkout for Magento

## Compatibility

- Magento Open Source 2.4.4 through 2.4.9
- PHP 8.1 through 8.5, using the PHP version officially supported by the installed Magento release
- Verified target environment: Magento 2.4.9 / Magento Framework 103.0.9 / Symfony Console 7.4

Before an upgrade, run `php bin/magento viva:compatibility:check`. Manual `app/code` installations
are also checked by `setup:upgrade`; unsupported versions stop with a clear compatibility error.

This build adds verified server-side polling, payment-attempt history, global/product-driven preauthorization and complete order-level Viva API auditing.

## Installation / upgrade

After copying the module, run:

```bash
bin/magento module:enable Ced_VivaPayments
bin/magento setup:upgrade
bin/magento setup:di:compile
bin/magento cache:flush
```

For production mode, deploy static content according to the Magento installation's normal release process.

## Required polling worker

Magento cron runs at most once per minute and cannot guarantee a sub-minute interval. Run exactly one persistent worker under systemd, Supervisor, Kubernetes or another process manager:

```bash
bin/magento viva:payments:poll
```

The worker safely serializes processing by payment attempt. A once-per-minute Magento cron job is included only as a fallback. Configuration is under **Stores > Configuration > Sales > Payment Methods > Viva.com Smart Checkout**:

- Enable Background Polling (default Yes)
- Initial Polling Delay in seconds (default 120; background only)
- Polling Interval in seconds (default 30)
- Order Payment Timeout in seconds (default 1800; `65535` prevents Viva expiration)
- Preauthorize All Orders (default No; takes priority over product flags)

The timeout is also sent to `POST /api/orders` as `paymentTimeout`. Each attempt stores its own expiry and initial delay. The callback always performs its final lookup immediately and never waits for the initial delay. The persistent worker reloads Admin configuration every 30 seconds.

The Viva.com Smart Checkout payment method is selected by default when it is available and the customer has not already selected another method.

A production systemd unit and installer are included under `deployment/systemd`. Install it once after the module upgrade. It automatically starts at boot, restarts after failures, and gracefully recycles without losing database-backed payment state.

## Preauthorization

Products include a **Viva Preauthorization** Yes/No attribute. If at least one visible basket item has Yes, the complete Viva payment order uses `isPreAuth=true`, with installments forced to 1. The flag is snapshotted onto the quote and sales order.

When **Preauthorize All Orders** is enabled, all Viva orders use `isPreAuth=true` and product flags are not evaluated. Existing orders retain their snapshot if the setting later changes.

A successful preauthorization (`StatusId=F` on an attempt already marked as preauthorization) does not create an invoice. `TransactionTypeId` is recorded but never used as a validation filter. The order view shows:

- **Capture**: opens the standard Magento invoice screen. Selected quantities determine the one allowed full or partial capture. After success, any un-invoiced quantities are cancelled and returned to stock when Magento inventory management is enabled.
- **Cancel Preauth**: releases the complete authorized amount and cancels the Magento order without an invoice or credit memo.

Refunds after capture use the capture transaction ID. Preauthorization, capture, cancellation and refund transactions remain as separate parent/child history records.

For a partial preauthorization invoice, reducing one or more item quantities enables **Final Shipping Fee**. The Admin enters the final base-currency shipping amount including tax; the value accepts only non-negative numbers with at most two decimal places. Capture is rejected before any Viva call when the final invoice exceeds the original authorization.

## Verification rules

Transactions are retrieved only with `GET /api/transactions/?ordercode={VivaOrderCode}`. Callback parameter `t`, when supplied, must exactly match a returned `TransactionId`; there is no fallback to the latest transaction. A successful payment also requires matching nested `Order.OrderCode`, Magento Order Increment ID in `MerchantTrns`, amount, and a non-empty `TransactionId`. `CurrencyCode`, `ErrorCode`, and `TransactionTypeId` are recorded but are not validation filters.

The order Admin has dedicated **Viva Payment Information** and **Viva Logs** tabs. Viva Logs stores every business API request and response body, query parameters, sanitized headers, HTTP status, timing, validation and state transition newest-first. Authorization headers, API keys and OAuth tokens are never persisted.

## Customer Back-button cancellation

When Viva returns the customer with `cancel=1`, transaction polling stops immediately and the module calls `DELETE /api/orders/{orderCode}` before cancelling the Magento order and restoring the basket. Technical DELETE failures use exponential retries of 10, 20, 40, 80, 160, then 300 seconds until the original payment expiry.


## Production Security: Storing Credentials in env.php

For maximum security, store your Viva credentials outside the database using Magento's `env.php` override. This keeps them off the Admin UI and out of any database backups.

Add the following to `app/etc/env.php`:

```php
'system' => [
    'default' => [
        'payment' => [
            'paymentmethod' => [
                'merchantid'     => 'your-merchant-id',
                'merchantpass'   => 'your-api-key',
                'merchantsource' => 'your-source-code',
            ],
        ],
    ],
],
```

When set via `env.php`, values are read directly from the filesystem and never written to `core_config_data`. The Admin panel fields will appear empty — this is expected behaviour.

> **Note:** `app/etc/env.php` must never be committed to version control.

2.7.13 release verification:
- PHP/PHTML syntax validated
- XML parsed successfully
- composer.json and db_schema_whitelist.json validated
