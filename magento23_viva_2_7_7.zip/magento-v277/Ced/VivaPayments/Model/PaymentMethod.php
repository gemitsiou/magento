<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Model;

use Ced\VivaPayments\Model\ResourceModel\VivaPayments as VivaPaymentsResource;
use Ced\VivaPayments\Service\VivaApiClient;
use Ced\VivaPayments\Service\AttemptManager;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Magento\Framework\UrlInterface;
use Magento\Payment\Helper\Data as PaymentData;
use Magento\Payment\Model\InfoInterface;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Payment\Model\Method\Logger;
use Magento\Sales\Model\Order;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Payment as OrderPayment;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Viva.com Smart Checkout payment method.
 *
 * Handles redirect-based payment integration with Viva Wallet.
 * The customer is redirected to Viva's hosted checkout page after order placement.
 *
 * Note: AbstractMethod is deprecated in Magento 2.4.x but still functional.
 * A full migration to the Payment Gateway framework (facade/command pattern)
 * is recommended as a follow-up for this redirect-based integration.
 */
class PaymentMethod extends AbstractMethod
{
    /**
     * Supported Viva Wallet currencies (ISO 4217 numeric codes).
     * Source: https://developer.viva.com/apis-for-payments/payment-api/#tag/Payments/operation/CreatePaymentOrder
     */
    private const CURRENCY_MAP = [
        'CZK' => 203,
        'DKK' => 208,
        'EUR' => 978,
        'GBP' => 826,
        'HUF' => 348,
        'PLN' => 985,
        'RON' => 946,
        'SEK' => 752,
    ];

    private const SUPPORTED_LANGUAGES = [
        'el-GR', 'bg-BG', 'cs-CZ', 'da-DK', 'de-DE', 'es-ES',
        'fi-FI', 'fr-FR', 'hr-HR', 'hu-HU', 'it-IT', 'nl-NL',
        'pl-PL', 'pt-PT', 'ro-RO', 'en-GB',
    ];

    /**
     * Payment method code.
     *
     * @var string
     */
    protected $_code = 'paymentmethod';

    /**
     * @var bool
     */
    protected $_isInitializeNeeded = true;

    /**
     * @var bool
     */
    protected $_canRefund = true;

    /**
     * @var bool
     */
    protected $_canRefundInvoicePartial = true;

    /**
     * @var bool
     */
    protected $_canCapture = true;

    /**
     * @var bool
     */
    protected $_canCapturePartial = true;

    protected $_canAuthorize = true;

    private StoreManagerInterface $storeManager;
    private ResolverInterface $localeResolver;
    private UrlInterface $urlBuilder;
    private VivaApiClient $vivaApiClient;
    private VivaPaymentsFactory $vivaPaymentsFactory;
    private VivaPaymentsResource $vivaResource;
    private AttemptManager $attemptManager;
    private OrderRepositoryInterface $orderRepository;

    /**
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        Registry $registry,
        ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        PaymentData $paymentData,
        ScopeConfigInterface $scopeConfig,
        Logger $logger,
        StoreManagerInterface $storeManager,
        ResolverInterface $localeResolver,
        UrlInterface $urlBuilder,
        VivaApiClient $vivaApiClient,
        VivaPaymentsFactory $vivaPaymentsFactory,
        VivaPaymentsResource $vivaResource,
        AttemptManager $attemptManager,
        OrderRepositoryInterface $orderRepository,
        ?AbstractResource $resource = null,
        ?AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );
        $this->storeManager = $storeManager;
        $this->localeResolver = $localeResolver;
        $this->urlBuilder = $urlBuilder;
        $this->vivaApiClient = $vivaApiClient;
        $this->vivaPaymentsFactory = $vivaPaymentsFactory;
        $this->vivaResource = $vivaResource;
        $this->attemptManager = $attemptManager;
        $this->orderRepository = $orderRepository;
    }

    /**
     * Get supported currency codes from config.
     *
     * @return string[]
     */
    public function getSupportedCurrencyCodes(): array
    {
        $allowed = $this->getConfigData('allowed_currency');
        return $allowed ? explode(',', (string) $allowed) : [];
    }

    /**
     * Check if the payment method can be used for the given currency.
     *
     * @param string $currencyCode
     */
    public function canUseForCurrency($currencyCode): bool
    {
        return in_array((string) $currencyCode, $this->getSupportedCurrencyCodes(), true);
    }

    /**
     * Initialize payment - set order to pending_payment state.
     *
     * @param string $paymentAction
     * @param object $stateObject
     */
    public function initialize($paymentAction, $stateObject): self
    {
        $payment = $this->getInfoInstance();
        $order = $payment->getOrder();
        $order->setCanSendNewEmailFlag(false);

        $stateObject->setState(Order::STATE_PENDING_PAYMENT);
        $stateObject->setStatus('pending_payment');
        $stateObject->setIsNotified(false);

        return $this;
    }

    /**
     * Build the redirect URL to the Viva Smart Checkout gateway.
     *
     * @throws LocalizedException
     */
    public function getRedirectUrl(Order $order): string
    {
        $billingAddress = $order->getBillingAddress();
        if ($billingAddress === null) {
            throw new LocalizedException(__('Billing address is required.'));
        }

        $currencyCode = (string) $order->getBaseCurrencyCode();
        $currencyNumeric = self::getNumericCurrencyCode($currencyCode);
        $locale = $this->resolveLocale();
        $amountCents = (int) round((float) $order->getBaseGrandTotal() * 100);

        // The global/product decision was snapshotted during quote submission.
        // Never let a later Admin or product change alter an already placed order.
        $isPreAuth = (bool) $order->getData('viva_is_preauth');
        $order->setData('viva_is_preauth', $isPreAuth ? 1 : 0);

        $vivaOrderCode = $this->attemptManager->withOrderLock(
            (string) $order->getIncrementId(),
            (int) $order->getStoreId(),
            function () use ($order, $billingAddress, $amountCents, $currencyNumeric, $locale, $isPreAuth): string {
                $existing = $this->attemptManager->getActiveAttemptForOrder(
                    (string) $order->getIncrementId(),
                    (int) $order->getStoreId()
                );
                if ($existing) {
                    $blockingStates = ['paid', 'preauth_payment', 'preauth_captured'];
                    if (in_array($existing['order_state'], $blockingStates, true)) {
                        throw new LocalizedException(
                            __('This order has already been paid. Please contact support.')
                        );
                    }
                    // pending or verification_error — reuse existing Viva order code
                    return (string) $existing['ordercode'];
                }

                $orderData = [
                    'amount_cents' => $amountCents,
                    'currency_code' => $currencyNumeric,
                    'merchant_trns' => $order->getIncrementId(),
                    'email' => (string) $billingAddress->getEmail(),
                    'phone' => (string) $billingAddress->getTelephone(),
                    'full_name' => trim($billingAddress->getFirstname() . ' ' . $billingAddress->getLastname()),
                    'locale' => $locale,
                    'is_pre_auth' => $isPreAuth,
                ];

                $vivaOrderCode = $this->vivaApiClient->createPaymentOrder($orderData, (int) $order->getStoreId());

                $this->savePaymentRecord(
                    $order,
                    $vivaOrderCode,
                    $amountCents,
                    $currencyNumeric,
                    $isPreAuth,
                    'Payment for Order ID ' . (string) $order->getIncrementId()
                );

                return $vivaOrderCode;
            }
        );

        $gatewayUrl = rtrim((string) $this->getConfigData('cgi_url'), '/');
        $params = ['Ref' => $vivaOrderCode];
        $checkoutColor = trim((string) $this->getConfigData('checkout_color'));
        if ($checkoutColor !== '') {
            $params['color'] = $checkoutColor;
        }

        return $gatewayUrl . '?' . http_build_query($params);
    }

    /**
     * Get the success URL.
     */
    public function getSuccessUrl(?int $storeId = null): string
    {
        return $this->buildUrl('checkout/onepage/success', $storeId);
    }

    /**
     * Get the cancel/failure URL.
     */
    public function getCancelUrl(?int $storeId = null): string
    {
        return $this->buildUrl('checkout/onepage/failure', $storeId);
    }

    /**
     * Validate payment info.
     *
     * @return $this
     * @throws LocalizedException
     */
    public function validate(): self
    {
        $data = $this->getInfoInstance();
        if ($data instanceof \Magento\Sales\Model\Order\Payment) {
            $address = $data->getOrder()->getBillingAddress();
            $billingCountry = $address ? (string) $address->getCountryId() : '';
            $currencyCode = (string) $data->getOrder()->getBaseCurrencyCode();
        } else {
            $address = $data->getQuote()->getBillingAddress();
            $billingCountry = $address ? (string) $address->getCountryId() : '';
            $currencyCode = (string) $data->getQuote()->getBaseCurrencyCode();
        }

        if (!$this->canUseForCountry($billingCountry)) {
            throw new LocalizedException(
                __('Selected payment type is not allowed for billing country.')
            );
        }

        $supportedCurrencies = $this->getSupportedCurrencyCodes();
        if (!empty($currencyCode) && !empty($supportedCurrencies)
            && !in_array($currencyCode, $supportedCurrencies, true)
        ) {
            throw new LocalizedException(
                __('Selected currency is not supported by this payment method.')
            );
        }

        return $this;
    }

    /**
     * Refund specified amount for payment.
     *
     * Issues an online refund API call to Viva Wallet and records the refund transaction.
     *
     * @param InfoInterface $payment
     * @param float|string $amount
     * @return $this
     * @throws LocalizedException
     */
    public function refund(InfoInterface $payment, $amount): self
    {
        if (!$this->canRefund()) {
            throw new LocalizedException(__('The refund action is not available.'));
        }

        if (!$payment instanceof OrderPayment) {
            throw new LocalizedException(__('Invalid payment instance for refund.'));
        }

        $order = $payment->getOrder();
        if ($order === null) {
            throw new LocalizedException(__('Order not found for refund.'));
        }

        // Locate original transaction ID
        $creditmemo = $payment->getCreditmemo();
        $transactionId = (string) $payment->getParentTransactionId();

        if (empty($transactionId) && $creditmemo && $creditmemo->getInvoice()) {
            $transactionId = (string) $creditmemo->getInvoice()->getTransactionId();
        }

        if (empty($transactionId)) {
            $transactionId = (string) $payment->getLastTransId();
        }

        if (empty($transactionId)) {
            throw new LocalizedException(
                __('Cannot refund: no valid transaction ID found on this payment.')
            );
        }

        $currencyCode = (string) $order->getBaseCurrencyCode();
        $currencyNumeric = self::getNumericCurrencyCode($currencyCode);
        $amountCents = (int) round((float) $amount * 100);
        $attempt = $this->attemptManager->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
        if (!$attempt || trim((string) ($attempt['customer_trns'] ?? '')) === '') {
            throw new LocalizedException(
                __('Cannot refund: the CustomerTrns of the original Viva transaction was not found.')
            );
        }
        return $this->attemptManager->withLock(
            (int) $attempt['id'],
            fn(): self => $this->doRefund($payment, $amount, $order, $attempt, $transactionId, $creditmemo)
        );
    }

    private function doRefund(
        OrderPayment $payment,
        $amount,
        \Magento\Sales\Model\Order $order,
        array $attempt,
        string $transactionId,
        $creditmemo
    ): self {
        $currencyCode = (string) $order->getBaseCurrencyCode();
        $currencyNumeric = self::getNumericCurrencyCode($currencyCode);
        $amountCents = (int) round((float) $amount * 100);

        $result = $this->vivaApiClient->refundTransaction(
            $transactionId,
            $amountCents,
            $currencyNumeric,
            (string) $order->getIncrementId(),
            (string) ($attempt['customer_trns'] ?? ''),
            (int) $order->getStoreId(),
            (string) $attempt['ordercode']
        );

        if ($attempt) {
            $this->attemptManager->recordTransaction(
                (int) $attempt['id'], 'refund', array_replace(
                    (array) ($result['response'] ?? []),
                    [
                        'TransactionId' => (string) ($result['transaction_id'] ?? ''),
                        'StatusId' => 'F', 'Amount' => (float) $amount,
                        'CurrencyCode' => $currencyNumeric, 'Success' => true,
                        'CustomerTrns' => (string) $attempt['customer_trns'],
                    ]
                ), $transactionId
            );
            $refundedCents = 0;
            $capturedCents = 0;
            foreach ($this->attemptManager->getTransactions((int) $attempt['id']) as $history) {
                if ($history['transaction_kind'] === 'refund') {
                    $refundedCents += (int) round((float) $history['amount'] * 100);
                } elseif (in_array($history['transaction_kind'], ['payment', 'capture'], true)) {
                    $capturedCents = max($capturedCents, (int) round((float) $history['amount'] * 100));
                }
            }
            $this->attemptManager->setState(
                (int) $attempt['id'], $capturedCents > 0 && $refundedCents >= $capturedCents ? 'refunded' : 'partially_refunded'
            );
        }

        $refundTransId = !empty($result['transaction_id'])
            ? $result['transaction_id']
            : $transactionId . '-refund';

        $payment->setTransactionId($refundTransId);
        $payment->setIsTransactionClosed(1);

        $shouldCloseParent = false;
        if ($creditmemo && $creditmemo->getInvoice()) {
            $shouldCloseParent = !$creditmemo->getInvoice()->canRefund();
        }
        $payment->setShouldCloseParentTransaction($shouldCloseParent);

        $orderComment = sprintf(
            "Viva.com Smart Checkout Refund Processed\nOriginal TxID: %s\nRefund TxID: %s",
            $transactionId,
            $refundTransId
        );
        $order->addCommentToStatusHistory($orderComment, false);

        return $this;
    }

    /** Capture the chosen Magento invoice total against the original preauthorization. */
    public function capture(InfoInterface $payment, $amount): self
    {
        if (!$payment instanceof OrderPayment || !$payment->getOrder()) {
            throw new LocalizedException(__('Invalid payment instance for preauthorization capture.'));
        }
        $order = $payment->getOrder();
        $attempt = $this->attemptManager->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
        if (!$attempt || empty($attempt['is_preauth']) || $attempt['order_state'] !== 'preauth_payment') {
            throw new LocalizedException(__('No open Viva preauthorization is available for capture.'));
        }
        return $this->attemptManager->withLock(
            (int) $attempt['id'],
            function () use ($payment, $amount, $order, $attempt): self {
                // Re-check state inside lock
                $fresh = $this->attemptManager->getByOrderCode((string) $attempt['ordercode']);
                if (!$fresh || $fresh['order_state'] !== 'preauth_payment') {
                    throw new LocalizedException(__('This preauthorization has already been captured or cancelled.'));
                }
                return $this->doCapturePreauth($payment, $amount, $order, $fresh);
            }
        );
    }

    private function doCapturePreauth(OrderPayment $payment, $amount, $order, array $attempt): self
    {
        $authorizedCents = (int) $attempt['amount_cents'];
        $captureCents = (int) round((float) $amount * 100);
        if ($captureCents <= 0) {
            throw new LocalizedException(__('Capture amount must be greater than zero.'));
        }
        if ($captureCents > $authorizedCents) {
            throw new LocalizedException(__(
                'The final invoice amount %1 %2 exceeds the authorized amount of %3 %2. Cancel this preauthorization and create a new order/payment authorization.',
                number_format($captureCents / 100, 2, '.', ''),
                (string) $order->getBaseCurrencyCode(),
                number_format($authorizedCents / 100, 2, '.', '')
            ));
        }
        $transactions = $this->attemptManager->getTransactions((int) $attempt['id']);
        $preauth = null;
        foreach ($transactions as $transaction) {
            if ($transaction['transaction_kind'] === 'preauthorization') { $preauth = $transaction; break; }
        }
        if (!$preauth) {
            throw new LocalizedException(__('The original Viva preauthorization transaction was not found.'));
        }
        $payload = [
            'amount' => $captureCents,
            'installments' => 1,
            'customerTrns' => 'Final Charge for Order ID ' . $order->getIncrementId(),
            'merchantTrns' => (string) $order->getIncrementId(),
            'sourceCode' => (string) $attempt['source_code'],
            'tipAmount' => 0,
            'currencyCode' => (int) $attempt['currency_code'],
        ];
        $result = $this->vivaApiClient->capturePreauthorization(
            (string) $preauth['transaction_id'], $payload, (int) $order->getStoreId(),
            (string) $order->getIncrementId(), (string) $attempt['ordercode']
        );
        $captureHistory = $result;
        $captureHistory['Amount'] = $captureHistory['Amount'] ?? (float) $amount;
        $captureHistory['CurrencyCode'] = $captureHistory['CurrencyCode'] ?? (int) $attempt['currency_code'];
        $this->attemptManager->recordTransaction(
            (int) $attempt['id'], 'capture', $captureHistory, (string) $preauth['transaction_id']
        );
        $this->attemptManager->stop((int) $attempt['id'], 'preauth_captured', 'capture_completed', $result);
        $finalShippingFee = (float) ($order->getBaseShippingInclTax()
            ?: ((float) $order->getBaseShippingAmount() + (float) $order->getBaseShippingTaxAmount()));
        $this->attemptManager->setFinalShippingFee((int) $attempt['id'], $finalShippingFee);
        $payment->setParentTransactionId((string) $preauth['transaction_id'])
            ->setTransactionId((string) $result['TransactionId'])
            ->setIsTransactionClosed(true)
            ->setShouldCloseParentTransaction(true);
        $order->addStatusHistoryComment(
            __('Viva Preauth Captured: %1 (%2).', $result['TransactionId'], $captureCents === $authorizedCents ? 'Full' : 'Partial')
        );
        return $this;
    }


    /**
     * Save a Viva payment tracking record.
     */
    private function savePaymentRecord(
        Order $order,
        string $orderCode,
        int $amountCents,
        int $currencyNumeric,
        bool $isPreAuth,
        string $customerTrns
    ): void {
        $billingAddress = $order->getBillingAddress();
        $ref = 'REF' . substr(md5(uniqid((string) random_int(0, PHP_INT_MAX), true)), 0, 9);

        $timeout = $this->vivaApiClient->getPaymentTimeout((int) $order->getStoreId());
        $initialDelay = (int) $this->_scopeConfig->getValue(
            'payment/paymentmethod/initial_polling_delay',
            ScopeInterface::SCOPE_STORE,
            (int) $order->getStoreId()
        );
        $initialDelay = $initialDelay > 0 ? $initialDelay : 120;
        $startedAt = time();
        $this->attemptManager->create([
            'ref' => $ref,
            'ordercode' => $orderCode,
            'email_address' => $billingAddress ? (string) $billingAddress->getEmail() : '',
            'order_id' => $order->getIncrementId(),
            'total_cost' => $amountCents,
            'currency' => (string) $currencyNumeric,
            'order_state' => 'pending',
            'timestamp' => gmdate('Y-m-d H:i:s'),
            'store_id' => (int) $order->getStoreId(),
            'amount_cents' => $amountCents,
            'currency_code' => $currencyNumeric,
            'currency_alpha' => (string) $order->getBaseCurrencyCode(),
            'source_code' => (string) $this->getConfigData('merchantsource'),
            'customer_trns' => $customerTrns,
            'original_shipping_fee' => (float) ($order->getBaseShippingInclTax()
                ?: ((float) $order->getBaseShippingAmount() + (float) $order->getBaseShippingTaxAmount())),
            'final_shipping_fee' => null,
            'is_preauth' => $isPreAuth ? 1 : 0,
            'payment_timeout' => $timeout,
            'initial_polling_delay' => $initialDelay,
            'started_at' => gmdate('Y-m-d H:i:s', $startedAt),
            'expires_at' => gmdate('Y-m-d H:i:s', $startedAt + $timeout),
            'next_poll_at' => gmdate('Y-m-d H:i:s', $startedAt + $initialDelay),
            // Keep the attempt eligible so an Admin enable/disable change is reversible.
            // The worker reads polling_enabled live before making any API call.
            'polling_active' => 1,
        ]);
        $order->setData('viva_payment_type', $isPreAuth ? 'preauthorization' : 'one_off');
        $order->setData('viva_order_code', $orderCode);
        $this->orderRepository->save($order);
    }

    public static function getNumericCurrencyCode(string $currencyCode): int
    {
        if (!isset(self::CURRENCY_MAP[$currencyCode])) {
            throw new LocalizedException(
                __('Base currency "%1" is not supported by Viva Payments.', $currencyCode)
            );
        }
        return self::CURRENCY_MAP[$currencyCode];
    }

    /**
     * Resolve the checkout language based on store locale.
     */
    private function resolveLocale(): string
    {
        $locale = (string) $this->localeResolver->getLocale();
        // Convert underscore format (en_GB) to dash format (en-GB) if needed
        $locale = str_replace('_', '-', $locale);

        if (!in_array($locale, self::SUPPORTED_LANGUAGES, true)) {
            return 'en-GB';
        }

        return $locale;
    }

    /**
     * Build a store-aware URL.
     */
    private function buildUrl(string $path, ?int $storeId = null): string
    {
        $store = $this->storeManager->getStore($storeId);

        return $this->urlBuilder->getUrl(
            $path,
            [
                '_store' => $store,
                '_secure' => $store->isCurrentlySecure(),
            ]
        );
    }
}
