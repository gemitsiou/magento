<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Controller\Adminhtml\Order;

use Ced\VivaPayments\Service\AttemptManager;
use Ced\VivaPayments\Service\VivaApiClient;
use Magento\Backend\App\Action;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;

class CancelPreauth extends Action implements HttpPostActionInterface
{
    public const ADMIN_RESOURCE = 'Ced_VivaPayments::cancel_preauth';
    private OrderRepositoryInterface $orders;
    private AttemptManager $attempts;
    private VivaApiClient $api;

    public function __construct(
        Action\Context $context, OrderRepositoryInterface $orders,
        AttemptManager $attempts, VivaApiClient $api
    ) { parent::__construct($context); $this->orders = $orders; $this->attempts = $attempts; $this->api = $api; }

    public function execute(): Redirect
    {
        $result = $this->resultRedirectFactory->create();
        $orderId = (int) $this->getRequest()->getParam('order_id');
        try {
            $order = $this->orders->get($orderId);
            $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId(), (int) $order->getStoreId());
            if (!$attempt || empty($attempt['is_preauth']) || $attempt['order_state'] !== 'preauth_payment') {
                throw new \Magento\Framework\Exception\LocalizedException(__('No open Viva preauthorization exists.'));
            }
            $this->attempts->withLock(
                (int) $attempt['id'],
                function () use ($order, $attempt): void {
                    // Re-check state inside lock — may have been captured or cancelled concurrently
                    $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
                    if (!$fresh || $fresh['order_state'] !== 'preauth_payment') {
                        throw new \Magento\Framework\Exception\LocalizedException(
                            __('This preauthorization has already been captured or cancelled.')
                        );
                    }
                    $preauth = null;
                    foreach ($this->attempts->getTransactions((int) $fresh['id']) as $transaction) {
                        if ($transaction['transaction_kind'] === 'preauthorization') { $preauth = $transaction; break; }
                    }
                    if (!$preauth) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('Original preauthorization not found.'));
                    }
                    $response = $this->api->cancelPreauthorization((string) $preauth['transaction_id'], [
                        'amount' => (int) $fresh['amount_cents'],
                        'sourceCode' => (string) $fresh['source_code'],
                        'merchantTrns' => (string) $order->getIncrementId(),
                        'customerTrns' => (string) $fresh['customer_trns'],
                        'currencyCode' => (int) $fresh['currency_code'],
                    ], (int) $order->getStoreId(), (string) $order->getIncrementId(), (string) $fresh['ordercode']);
                    $this->attempts->recordTransaction(
                        (int) $fresh['id'], 'preauth_cancel', $response, (string) $preauth['transaction_id']
                    );
                    $this->attempts->stop((int) $fresh['id'], 'preauth_cancelled', 'administrator_cancelled', $response);
                    if ($order->canCancel()) { $order->cancel(); }
                    $order->addStatusHistoryComment(__('Viva Preauthorization Cancelled. Transaction: %1', $response['TransactionId']));
                    $this->orders->save($order);
                }
            );
            $this->messageManager->addSuccessMessage(__('The Viva preauthorization was cancelled.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
        return $result->setPath('sales/order/view', ['order_id' => $orderId]);
    }
}
