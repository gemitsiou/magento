<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Controller\Checkout;

use Ced\VivaPayments\Model\PaymentMethod;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Message\ManagerInterface as MessageManager;
use Psr\Log\LoggerInterface;

/**
 * Initiates checkout by creating a Viva payment order and redirecting to the gateway.
 */
class Start implements HttpGetActionInterface
{
    private PaymentMethod $paymentMethod;
    private CheckoutSession $checkoutSession;
    private RedirectFactory $redirectFactory;
    private LoggerInterface $logger;
    private MessageManager $messageManager;

    public function __construct(
        PaymentMethod $paymentMethod,
        CheckoutSession $checkoutSession,
        RedirectFactory $redirectFactory,
        LoggerInterface $logger,
        MessageManager $messageManager
    ) {
        $this->paymentMethod = $paymentMethod;
        $this->checkoutSession = $checkoutSession;
        $this->redirectFactory = $redirectFactory;
        $this->logger = $logger;
        $this->messageManager = $messageManager;
    }

    /**
     * Redirect customer to Viva Smart Checkout gateway.
     *
     * @return Redirect
     */
    public function execute(): Redirect
    {
        try {
            $order = $this->checkoutSession->getLastRealOrder();

            if (!$order || !$order->getId()) {
                $this->logger->error('VivaPayments Start: No order found in session');
                return $this->createErrorRedirect();
            }

            $redirectUrl = $this->paymentMethod->getRedirectUrl($order);

            /** @var Redirect $result */
            $result = $this->redirectFactory->create();
            $result->setUrl($redirectUrl);

            return $result;
        } catch (LocalizedException $e) {
            $this->logger->error('VivaPayments Start error', [
                'message' => $e->getMessage(),
            ]);
            $this->messageManager->addErrorMessage($e->getMessage());
            return $this->createErrorRedirect();
        } catch (\Exception $e) {
            $this->logger->critical('VivaPayments Start unexpected error', [
                'exception' => $e->getMessage(),
            ]);
            $this->messageManager->addErrorMessage(
                __('Payment service is temporarily unavailable. Please try again later.')
            );
            return $this->createErrorRedirect();
        }
    }

    /**
     * Create a redirect back to checkout/cart on error.
     */
    private function createErrorRedirect(): Redirect
    {
        /** @var Redirect $redirect */
        $redirect = $this->redirectFactory->create();
        $redirect->setPath('checkout/cart');
        return $redirect;
    }
}