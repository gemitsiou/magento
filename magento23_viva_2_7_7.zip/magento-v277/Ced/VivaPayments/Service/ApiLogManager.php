<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Service;

use Magento\Framework\App\ResourceConnection;
use Psr\Log\LoggerInterface;

class ApiLogManager
{
    private ResourceConnection $resource;
    private LoggerInterface $logger;

    public function __construct(ResourceConnection $resource, LoggerInterface $logger)
    {
        $this->resource = $resource;
        $this->logger = $logger;
    }

    /**
     * Best-effort record — never throws. Failures are logged to system log only.
     */
    public function safeRecord(array $data): int
    {
        try {
            return $this->record($data);
        } catch (\Throwable $e) {
            $this->logger->warning('Viva API log write failed — payment result unaffected', [
                'error' => $e->getMessage(),
                'operation' => $data['operation'] ?? 'unknown',
                'order_id' => $data['order_id'] ?? 'unknown',
            ]);
            return 0;
        }
    }

    /**
     * Best-effort updateOutcome — never throws.
     */
    public function safeUpdateOutcome(int $id, array $data): void
    {
        try {
            $this->updateOutcome($id, $data);
        } catch (\Throwable $e) {
            $this->logger->warning('Viva API log update failed — payment result unaffected', [
                'error' => $e->getMessage(),
                'log_id' => $id,
            ]);
        }
    }

    public function record(array $data): int
    {
        $connection = $this->resource->getConnection();
        $connection->insert($this->resource->getTableName('vivapayments_api_log'), [
            'order_id' => (string) ($data['order_id'] ?? ''),
            'store_id' => (int) ($data['store_id'] ?? 0),
            'ordercode' => $this->nullable($data['ordercode'] ?? null),
            'operation' => (string) ($data['operation'] ?? 'unknown'),
            'trigger_source' => (string) ($data['trigger_source'] ?? 'Server'),
            'http_method' => strtoupper((string) ($data['http_method'] ?? '')),
            'endpoint' => (string) ($data['endpoint'] ?? ''),
            'query_data' => $this->json($data['query_data'] ?? null),
            'request_headers' => $this->json($data['request_headers'] ?? null),
            'request_body' => $this->body($data['request_body'] ?? null),
            'http_status' => max(0, (int) ($data['http_status'] ?? 0)),
            'response_body' => $this->body($data['response_body'] ?? null),
            'result' => (string) ($data['result'] ?? 'Unknown'),
            'validation_data' => $this->json($data['validation_data'] ?? null),
            'state_before' => $this->nullable($data['state_before'] ?? null),
            'state_after' => $this->nullable($data['state_after'] ?? null),
            'error_message' => $this->nullable($data['error_message'] ?? null),
            'duration_ms' => max(0, (int) ($data['duration_ms'] ?? 0)),
            'created_at' => gmdate('Y-m-d H:i:s'),
        ]);
        return (int) $connection->lastInsertId();
    }

    public function getByOrder(string $incrementId, int $storeId, int $limit = 50, int $offset = 0): array
    {
        $connection = $this->resource->getConnection();
        return $connection->fetchAll(
            $connection->select()->from($this->resource->getTableName('vivapayments_api_log'))
                ->where('order_id = ?', $incrementId)
                ->where('store_id = ?', $storeId)
                ->order('id DESC')->limit(max(1, $limit), max(0, $offset))
        );
    }

    public function countByOrder(string $incrementId, int $storeId): int
    {
        $connection = $this->resource->getConnection();
        return (int) $connection->fetchOne(
            $connection->select()->from($this->resource->getTableName('vivapayments_api_log'), 'COUNT(*)')
                ->where('order_id = ?', $incrementId)
                ->where('store_id = ?', $storeId)
        );
    }

    public function updateOutcome(int $id, array $data): void
    {
        if ($id <= 0 || $data === []) { return; }
        $allowed = ['ordercode', 'result', 'validation_data', 'state_before', 'state_after', 'error_message'];
        $update = [];
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $data)) { continue; }
            $update[$key] = $key === 'validation_data' ? $this->json($data[$key]) : $this->nullable($data[$key]);
        }
        if ($update) {
            $this->resource->getConnection()->update(
                $this->resource->getTableName('vivapayments_api_log'), $update, ['id = ?' => $id]
            );
        }
    }

    private function json($value): ?string
    {
        if ($value === null || $value === [] || $value === '') { return null; }
        $json = json_encode(
            $value,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE
        );
        return $json === false ? '{"_error":"Unable to encode audit data"}' : $json;
    }

    private function body($value): ?string
    {
        if ($value === null || $value === '') { return null; }
        return is_array($value) ? $this->json($value) : (string) $value;
    }

    private function nullable($value): ?string
    {
        return $value === null || $value === '' ? null : (string) $value;
    }
}
