<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Service;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Lock\LockManagerInterface;
use Magento\Store\Model\ScopeInterface;
use Psr\Log\LoggerInterface;

/** Browser-independent transaction polling and Viva payment-order cancellation worker. */
class PaymentPoller
{
    private VivaApiClient $api;
    private AttemptManager $attempts;
    private OrderProcessor $orders;
    private ScopeConfigInterface $scopeConfig;
    private LoggerInterface $logger;
    private ApiLogManager $apiLogs;
    private LockManagerInterface $lockManager;

    public function __construct(
        VivaApiClient $api,
        AttemptManager $attempts,
        OrderProcessor $orders,
        ScopeConfigInterface $scopeConfig,
        LoggerInterface $logger,
        ApiLogManager $apiLogs,
        LockManagerInterface $lockManager
    ) {
        $this->api = $api;
        $this->attempts = $attempts;
        $this->orders = $orders;
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
        $this->apiLogs = $apiLogs;
        $this->lockManager = $lockManager;
    }

    public function pollDue(int $limit = 100): int
    {
        // Global lock prevents concurrent worker + cron duplicate polling.
        $lockName = 'ced_viva_poll_worker';
        if (!$this->lockManager->lock($lockName, 0)) {
            $this->logger->info('Viva poll skipped: another worker is already running.');
            return 0;
        }
        $processed = 0;
        try {
            return $this->doPollDue($limit);
        } finally {
            $this->lockManager->unlock($lockName);
        }
    }

    private function doPollDue(int $limit = 100): int
    {
        $processed = 0;

        // Customer-requested DELETE retries have priority and are independent of polling_enabled.
        foreach ($this->attempts->getDueCancellationRetries($limit) as $attempt) {
            try {
                $this->retryPaymentOrderCancellation($attempt);
                $processed++;
            } catch (\Throwable $e) {
                $this->logger->error('Viva payment order cancellation worker failure', [
                    'order_code' => $attempt['ordercode'], 'error' => $e->getMessage(),
                ]);
            }
        }
        $this->attempts->expireCancellationRetries();

        foreach ($this->attempts->getExpiredAttempts($limit) as $attempt) {
            if (!$this->isPollingEnabled((int) $attempt['store_id'])) {
                continue;
            }
            try {
                $this->pollAttempt($attempt, true, null, true);
                $processed++;
            } catch (\Throwable $e) {
                $this->logger->error('Viva final timeout poll failed', [
                    'order_code' => $attempt['ordercode'], 'error' => $e->getMessage(),
                ]);
            }
        }

        foreach ($this->attempts->getDueAttempts($limit) as $attempt) {
            if (!$this->isPollingEnabled((int) $attempt['store_id'])) {
                continue;
            }
            try {
                $this->pollAttempt($attempt, false);
                $processed++;
            } catch (\Throwable $e) {
                $this->logger->error('Viva polling attempt failed', [
                    'order_code' => $attempt['ordercode'], 'error' => $e->getMessage(),
                ]);
            }
        }
        return $processed;
    }

    /** Callback calls use final=true and never wait for the background polling schedule. */
    public function pollAttempt(
        array $attempt,
        bool $final,
        ?string $callbackTransactionId = null,
        bool $timeout = false
    ): array {
        return $this->attempts->withLock(
            (int) $attempt['id'],
            function () use ($attempt, $final, $callbackTransactionId, $timeout): array {
                $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
                if (!$fresh) {
                    throw new \RuntimeException('Payment attempt no longer exists.');
                }
                // Terminal state guard: do not re-process attempts that are already in a final state.
                $terminalStates = ['paid', 'preauth_payment', 'preauth_captured', 'failed', 'expired', 'cancelled', 'preauth_cancelled', 'refunded'];
                if (empty($fresh['polling_active'])
                    && in_array($fresh['order_state'], $terminalStates, true)
                ) {
                    $stored = json_decode((string) ($fresh['response_data'] ?? ''), true) ?: [];
                    if ($callbackTransactionId !== null
                        && (string) ($stored['TransactionId'] ?? '') !== $callbackTransactionId
                    ) {
                        return $this->result(
                            'verification_error',
                            'The callback transaction ID does not match the processed transaction.'
                        );
                    }
                    return [
                        'verified' => true, 'state' => $fresh['order_state'],
                        'transaction_id' => (string) ($stored['TransactionId'] ?? ''),
                        'amount' => (float) ($stored['Amount'] ?? 0), 'status_id' => 'F',
                        'message' => 'Transaction was already processed.', 'error_type' => '',
                        'response_type' => 'transaction', 'transaction' => $stored,
                    ];
                }
                return $this->processAttempt($fresh, $final, $callbackTransactionId, $timeout);
            }
        );
    }

    /** Handle cancel=1: stop polling first, immediately DELETE the Viva order. */
    public function cancelPaymentOrder(array $attempt): array
    {
        return $this->attempts->withLock((int) $attempt['id'], function () use ($attempt): array {
            $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
            if (!$fresh) {
                throw new \RuntimeException('Payment attempt no longer exists.');
            }
            // Step 1: Reject immediately if local state is already a completed payment.
            $nonCancellableStates = ['paid', 'preauth_payment', 'preauth_captured'];
            if (in_array($fresh['order_state'], $nonCancellableStates, true)) {
                $this->logger->warning('Viva customer cancellation rejected: local state already completed', [
                    'order_code' => $fresh['ordercode'],
                    'order_state' => $fresh['order_state'],
                ]);
                return ['success' => false, 'message' => 'Payment already completed — cancellation rejected.'];
            }

            // Step 2: Final Viva API verification — the payment may have completed at Viva
            // but the poller hasn't processed it yet (local state still pending).
            $storeId = (int) $fresh['store_id'];
            $verification = $this->api->verifyTransaction(
                (string) $fresh['ordercode'],
                null,
                $storeId > 0 ? $storeId : null,
                [
                    'order_code'    => (string) $fresh['ordercode'],
                    'merchant_trns' => (string) $fresh['order_id'],
                    'amount_cents'  => (int) $fresh['amount_cents'],
                    'currency_code' => (int) $fresh['currency_code'],
                ]
            );
            if (!empty($verification['verified'])) {
                // Payment confirmed at Viva — process it and reject the cancellation.
                $this->logger->warning('Viva customer cancellation rejected: Viva confirms payment completed', [
                    'order_code'     => $fresh['ordercode'],
                    'transaction_id' => $verification['transaction_id'],
                ]);
                $order = $this->orders->loadOrder(
                    (string) $fresh['order_id'],
                    $storeId > 0 ? $storeId : null
                );
                if (!empty($fresh['is_preauth'])) {
                    $this->orders->processSuccessfulPreauthorization(
                        $order, (string) $verification['transaction_id'],
                        (float) $verification['amount'], (string) $verification['message']
                    );
                    $this->attempts->stop((int) $fresh['id'], 'preauth_payment', 'verified_on_cancel', $verification['transaction'] ?? []);
                } else {
                    $this->orders->processSuccessfulPayment(
                        $order, (string) $verification['transaction_id'],
                        (float) $verification['amount'], (string) $verification['message']
                    );
                    $this->attempts->stop((int) $fresh['id'], 'paid', 'verified_on_cancel', $verification['transaction'] ?? []);
                }
                return ['success' => false, 'message' => 'Payment already completed — cancellation rejected.'];
            }

            // Step 3: No completed payment found — proceed with cancellation.
            $this->attempts->requestCustomerCancellation((int) $fresh['id']);
            $result = $this->api->cancelPaymentOrder(
                (string) $fresh['ordercode'],
                $storeId > 0 ? $storeId : null,
                (string) $fresh['order_id'],
                'Customer Callback'
            );
            $this->attempts->recordCancellationAttempt((int) $fresh['id'], $result);
            $this->logger->info('Viva customer cancellation state transition', [
                'order_code' => $fresh['ordercode'], 'magento_order' => $fresh['order_id'],
                'from' => $fresh['order_state'], 'to' => 'cancelled', 'delete_result' => $result,
            ]);
            return $result;
        });
    }

    private function retryPaymentOrderCancellation(array $attempt): void
    {
        $this->attempts->withLock((int) $attempt['id'], function () use ($attempt): void {
            $fresh = $this->attempts->getByOrderCode((string) $attempt['ordercode']);
            if (!$fresh || empty($fresh['cancel_retry_active'])) {
                return;
            }
            $result = $this->api->cancelPaymentOrder(
                (string) $fresh['ordercode'], (int) $fresh['store_id'],
                (string) $fresh['order_id'], 'Cancellation Retry'
            );
            $this->attempts->recordCancellationAttempt((int) $fresh['id'], $result);
        });
    }

    private function processAttempt(
        array $attempt,
        bool $final,
        ?string $callbackTransactionId,
        bool $timeout
    ): array {
        // Re-check inside lock: another worker may have already polled this attempt.
        if (!$final && !$timeout
            && !empty($attempt['next_poll_at'])
            && strtotime((string) $attempt['next_poll_at']) > time()
        ) {
            return $this->result('pending', 'Poll skipped: attempt no longer due.');
        }

        $storeId = isset($attempt['store_id']) ? (int) $attempt['store_id'] : null;
        $expected = [
            'order_code'    => (string) $attempt['ordercode'],
            'merchant_trns' => (string) $attempt['order_id'],
            'amount_cents'  => (int) $attempt['amount_cents'],
            'currency_code' => (int) $attempt['currency_code'],
        ];
        $result = $this->api->verifyTransaction(
            (string) $attempt['ordercode'], $callbackTransactionId, $storeId, $expected,
            $callbackTransactionId !== null
                ? 'Customer Callback'
                : ($timeout ? 'Timeout Final Poll' : ($final ? 'Final Poll' : 'Background Polling'))
        );
        $transaction = $result['transaction'] ?? [];
        if ($transaction !== []) {
            $this->attempts->recordTransaction(
                (int) $attempt['id'],
                !empty($attempt['is_preauth']) ? 'preauthorization' : 'payment',
                $transaction
            );
        }

        if (!empty($result['verified'])) {
            $order = $this->orders->loadOrder((string) $attempt['order_id'], isset($attempt['store_id']) ? (int) $attempt['store_id'] : null);
            if (!empty($attempt['is_preauth'])) {
                $this->orders->processSuccessfulPreauthorization(
                    $order, (string) $result['transaction_id'], (float) $result['amount'],
                    (string) $result['message']
                );
                $state = 'preauth_payment';
            } else {
                $this->orders->processSuccessfulPayment(
                    $order, (string) $result['transaction_id'], (float) $result['amount'],
                    (string) $result['message']
                );
                $state = 'paid';
            }
            $this->attempts->stop((int) $attempt['id'], $state, 'successful_transaction', $transaction);
            $result['state'] = $state;
            $this->logTransition($attempt, $state, $result);
            $this->updateApiTransition($result, (string) $attempt['order_state'], $state);
            return $result;
        }

        $state = $this->resolveState($result, $final, $timeout);
        $result['state'] = $state;
        if (in_array($state, ['failed', 'expired'], true)) {
            $order = $this->orders->loadOrder((string) $attempt['order_id'], isset($attempt['store_id']) ? (int) $attempt['store_id'] : null);
            if ($state === 'expired') {
                $this->orders->processExpiredPayment($order, (string) $result['message']);
            } else {
                $this->orders->processFailedPayment($order, (string) $result['message']);
            }
            $this->attempts->stop(
                (int) $attempt['id'], $state,
                $timeout ? 'payment_timeout' : 'terminal_payment_status', $transaction
            );
        } elseif ($final) {
            $order = $this->orders->loadOrder((string) $attempt['order_id'], isset($attempt['store_id']) ? (int) $attempt['store_id'] : null);
            $this->orders->processPendingReconciliation($order, (string) $result['message']);
            // Do not stop polling on pending/verification_error from callback —
            // let the background worker continue until the attempt expires.
            if ($timeout) {
                $storedState = $state === 'verification_error' ? 'verification_error' : 'pending';
                $this->attempts->stop(
                    (int) $attempt['id'], $storedState, 'payment_timeout_reconciliation', $transaction
                );
            } else {
                // Customer return with pending result — keep polling active
                $this->attempts->markPolled(
                    (int) $attempt['id'],
                    $this->getInterval($storeId),
                    $state === 'verification_error' ? 'verification_error' : 'pending',
                    $transaction
                );
            }
        } else {
            $this->attempts->markPolled(
                (int) $attempt['id'], $this->getInterval($storeId), 'pending', $transaction
            );
        }
        $this->logTransition($attempt, $state, $result);
        $this->updateApiTransition($result, (string) $attempt['order_state'], $state);
        return $result;
    }

    private function updateApiTransition(array $result, string $before, string $after): void
    {
        $this->apiLogs->safeUpdateOutcome((int) ($result['api_log_id'] ?? 0), [
            'state_before' => $before,
            'state_after' => $after,
            'validation_data' => [
                'verified' => (bool) ($result['verified'] ?? false),
                'status_id' => (string) ($result['status_id'] ?? ''),
                'response_type' => (string) ($result['response_type'] ?? ''),
                'message' => (string) ($result['message'] ?? ''),
            ],
        ]);
    }

    private function resolveState(array $result, bool $final, bool $timeout): string
    {
        $type = (string) ($result['response_type'] ?? 'technical_error');
        if ($type === 'technical_error' || $type === 'verification_error') {
            return 'verification_error';
        }
        if ($type === 'empty') {
            return $timeout ? 'expired' : 'pending';
        }
        switch (strtoupper((string) ($result['status_id'] ?? ''))) {
            case 'F': return 'verification_error';
            case 'E': return ($final || $timeout) ? 'failed' : 'pending';
            case 'A': return $timeout ? 'expired' : 'pending';
            case 'X': return 'failed';
            case 'R': return 'verification_error';
            default: return $final ? 'verification_error' : 'pending';
        }
    }

    private function result(string $state, string $message): array
    {
        return [
            'verified' => false, 'state' => $state, 'transaction_id' => '',
            'amount' => 0.0, 'status_id' => '', 'message' => $message,
            'error_type' => 'verification', 'response_type' => 'verification_error',
            'transaction' => [],
        ];
    }

    private function isPollingEnabled(int $storeId): bool
    {
        return (bool) $this->scopeConfig->getValue(
            'payment/paymentmethod/polling_enabled', ScopeInterface::SCOPE_STORE, $storeId
        );
    }

    public function getInterval(?int $storeId = null): int
    {
        $value = (int) $this->scopeConfig->getValue(
            'payment/paymentmethod/polling_interval', ScopeInterface::SCOPE_STORE, $storeId
        );
        return max(5, $value > 0 ? $value : 30);
    }

    /** Recalculate pending schedules after the long-running worker reloads Admin configuration. */
    public function refreshSchedulesFromConfiguration(): void
    {
        $storeConfig = [];
        foreach ($this->attempts->getActiveAttemptsForScheduling() as $attempt) {
            $storeId = (int) $attempt['store_id'];
            if (!isset($storeConfig[$storeId])) {
                $delay = (int) $this->scopeConfig->getValue(
                    'payment/paymentmethod/initial_polling_delay',
                    ScopeInterface::SCOPE_STORE,
                    $storeId
                );
                $storeConfig[$storeId] = [
                    'delay' => $delay > 0 ? $delay : 120,
                    'interval' => $this->getInterval($storeId),
                ];
            }
            $firstPoll = (int) $attempt['poll_attempts'] === 0;
            $base = $firstPoll ? (string) $attempt['started_at'] : (string) $attempt['last_polled_at'];
            $baseTimestamp = strtotime($base);
            if ($baseTimestamp === false) {
                continue;
            }
            $seconds = $firstPoll
                ? $storeConfig[$storeId]['delay']
                : $storeConfig[$storeId]['interval'];
            $next = gmdate('Y-m-d H:i:s', $baseTimestamp + $seconds);
            if ($next !== (string) $attempt['next_poll_at']) {
                $this->attempts->reschedule(
                    (int) $attempt['id'],
                    $next,
                    $firstPoll ? $storeConfig[$storeId]['delay'] : null
                );
            }
        }
    }

    private function logTransition(array $attempt, string $state, array $result): void
    {
        $this->logger->info('Viva payment state transition', [
            'order_code' => $attempt['ordercode'], 'magento_order' => $attempt['order_id'],
            'from' => $attempt['order_state'], 'to' => $state,
            'transaction_id' => $result['transaction_id'] ?? '',
            'status_id' => $result['status_id'] ?? '',
            'failed_criteria' => $result['message'] ?? '',
            'transaction' => $result['transaction'] ?? [],
        ]);
    }
}
