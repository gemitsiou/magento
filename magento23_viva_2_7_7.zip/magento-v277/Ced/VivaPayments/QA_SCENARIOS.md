# Viva.com Smart Checkout 2.7.0 QA scenarios

Defaults: background polling enabled, initial delay 120 seconds, polling interval 30 seconds, payment timeout 1800 seconds.

| Scenario | Expected result |
| --- | --- |
| Background lookup returns `Transactions: []` before expiry | Attempt remains Pending; no invoice/cancellation; next lookup is scheduled. |
| Final valid lookup returns `Transactions: []` at/after expiry | Attempt becomes Expired; Magento order is cancelled and stock is released. |
| Background lookup returns matching `StatusId=E` before expiry | Attempt remains Pending and polling continues. |
| A later lookup returns matching `StatusId=F` | Attempt becomes Success; normal payment creates one invoice, preauth creates no invoice. |
| Final timeout lookup returns matching `StatusId=E` | Attempt becomes Failed; Magento order is cancelled and stock is released. |
| Lookup returns matching `StatusId=A` before expiry | Attempt remains Pending. |
| Lookup returns matching `StatusId=X` | Attempt becomes Failed/Cancelled; Magento order is cancelled and stock is released. |
| Lookup unexpectedly returns `StatusId=R` for an active attempt | Verification Error/Pending reconciliation; it is never treated as a new successful payment. |
| Callback returns matching `StatusId=F` | Callback processes immediately, stops polling and redirects to success. |
| Callback returns matching `StatusId=E` | Attempt becomes Failed; order is cancelled; basket and stock are restored. |
| Callback returns `Transactions: []` before expiry | Attempt remains Pending for reconciliation; polling stops; quote is not restored. |
| Callback returns `Transactions: []` after expiry | Attempt becomes Expired; order is cancelled; basket and stock are restored. |
| Callback `t` is not present in returned transactions | Verification Error; no fallback transaction; no invoice/cancellation. |
| `Order.OrderCode`, `MerchantTrns`, or amount does not match | Verification Error; no invoice/cancellation. |
| `CurrencyCode`, `ErrorCode`, or `TransactionTypeId` differs | Difference is recorded but does not reject an otherwise valid transaction. |
| HTTP/network/invalid JSON before expiry | Pending and retry during background polling. |
| HTTP/network/invalid JSON on final callback/timeout lookup | Pending for reconciliation; no invoice/cancellation. |
| Duplicate success callback | No duplicate invoice or payment processing. |
| Multiple matching transactions include `F` | Matching `F` is selected; otherwise newest `InsDate` is selected. |
| Callback includes `cancel=1` | Polling stops, DELETE `/api/orders/{orderCode}` runs immediately, order is cancelled and basket/stock restored. |
| Initial cancellation DELETE has technical failure | Magento remains Cancelled; DELETE retries at 10, 20, 40, 80, 160, then 300-second intervals until original expiry. |
| Admin changes polling settings while worker runs | New values are observed within 30 seconds without manual worker restart. |
| Worker receives SIGTERM or reaches one-hour runtime | It exits between cycles; systemd restarts it without losing database-backed state. |
| Successful preauthorization | Order status becomes Preauth Payment; no invoice exists and shipment is unavailable. |
| Open preauthorization invoice screen | Only Capture Online is available; Capture Offline and Not Capture are unavailable and rejected server-side. |
| Full preauthorization capture | Viva capture succeeds, one paid invoice is created, and the order becomes Processing. |
| Partial preauthorization capture | Selected invoice quantities determine the online capture amount; un-invoiced quantities are cancelled/restocked after success. |
| Cancel Preauth | Full authorization is released through Viva, original CustomerTrns is sent, and the Magento order becomes Cancelled. |
| Normal/captured payment credit memo | Only Refund Online is available; full and partial refunds send the original CustomerTrns and record the refund transaction. |
| Successful normal payment | One paid invoice is created and the order becomes Processing; shipment changes it to Complete when Magento considers it fully fulfilled. |
| Orders grid | Viva Payment Type, Viva Payment Order and original Viva Transaction ID are populated and filterable. |
| Viva Payment Information | Nested Order, Payment, CreditCard, Dcc and TransactionType fields render one per row; installments, surcharge, conversion and original-currency data are visible. |
| Digital wallet response | DigitalWalletId shows its numeric value and mapped label; null displays a dash. |
| Compatibility command | `viva:compatibility:check` reports Compatible on Magento 2.4.4-2.4.9 with PHP 8.1-8.5 combinations supported by that Magento release. |
| Checkout has no previously selected payment method | Viva.com Smart Checkout is selected by default; a later customer selection is preserved. |
| Preauthorize All Orders = Yes | Every Viva order uses `isPreAuth=true`; product flags are not evaluated. |
| Preauthorize All Orders = No | Preauth is used only when at least one basket product has the product flag. |
| Partial preauth invoice reduces quantities | Final Shipping Fee becomes editable and accepts a non-negative amount with at most two decimals. |
| Invoice quantities remain unchanged | Final Shipping Fee remains locked to the original shipping fee. |
| Final invoice exceeds authorization | UI blocks submission and backend rejects it without a Viva call or invoice creation. |
| Order API history | Viva Logs contains every request/query and complete response newest-first, without credentials or access tokens. |
| Order Admin navigation | Viva Payment Information and Viva Logs appear as separate left-side tabs only for Viva orders. |

For each scenario verify `var/log/system.log`, Magento order history, Viva Payment Information in Admin, invoice count, stock quantity, and the `vivapayments_data`/`vivapayments_transaction` records.
