<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Block\Adminhtml\Order;

use Ced\VivaPayments\Service\ApiLogManager;
use Magento\Backend\Block\Template;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Framework\Registry;

class VivaLogs extends Template implements TabInterface
{
    private const PAGE_SIZE = 50;
    private Registry $registry;
    private ApiLogManager $logs;

    public function __construct(Template\Context $context, Registry $registry, ApiLogManager $logs, array $data = [])
    {
        parent::__construct($context, $data);
        $this->registry = $registry;
        $this->logs = $logs;
    }

    public function getLogs(): array
    {
        $order = $this->registry->registry('current_order');
        if (!$order || !$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') {
            return [];
        }
        return $this->logs->getByOrder(
            (string) $order->getIncrementId(),
            (int) $order->getStoreId(),
            self::PAGE_SIZE,
            ($this->getCurrentPage() - 1) * self::PAGE_SIZE
        );
    }

    public function getCurrentPage(): int
    {
        return max(1, (int) $this->getRequest()->getParam('viva_log_page', 1));
    }

    public function getPageCount(): int
    {
        $order = $this->registry->registry('current_order');
        if (!$order) { return 1; }
        return max(1, (int) ceil($this->logs->countByOrder((string) $order->getIncrementId(), (int) $order->getStoreId()) / self::PAGE_SIZE));
    }

    public function getPageUrl(int $page): string
    {
        $order = $this->registry->registry('current_order');
        return $this->getUrl('sales/order/view', [
            'order_id' => $order ? (int) $order->getId() : 0,
            'viva_log_page' => max(1, $page),
            '_fragment' => 'ced_vivapayments_order_logs_tab',
        ]);
    }

    public function pretty($value): string
    {
        if ($value === null || $value === '') { return '–'; }
        $decoded = json_decode((string) $value, true);
        return json_last_error() === JSON_ERROR_NONE
            ? (string) json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
            : (string) $value;
    }


    public function decoded($value): array
    {
        if ($value === null || $value === '') { return []; }
        if (is_array($value)) { return $value; }
        $decoded = json_decode((string) $value, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) { return $decoded; }
        parse_str((string) $value, $form);
        return is_array($form) && $form !== [] ? $form : ['value' => (string) $value];
    }

    public function pathParameters(array $log): array
    {
        $path = (string) (parse_url((string) ($log['endpoint'] ?? ''), PHP_URL_PATH) ?: '');
        $segments = array_values(array_filter(explode('/', trim($path, '/')), static fn($v) => $v !== ''));
        $result = [];
        foreach ($segments as $index => $segment) { $result['segment_' . ($index + 1)] = $segment; }
        if (!empty($log['ordercode'])) { $result['ordercode'] = (string) $log['ordercode']; }
        return $result;
    }

    public function stateTransition(array $log): string
    {
        $before = trim((string) ($log['state_before'] ?? ''));
        $after = trim((string) ($log['state_after'] ?? ''));
        return ($before !== '' || $after !== '') ? (($before ?: '–') . ' → ' . ($after ?: '–')) : '–';
    }
    public function getTabLabel() { return __('Viva Logs'); }
    public function getTabTitle() { return __('Viva Logs'); }
    public function canShowTab(): bool
    {
        $order = $this->registry->registry('current_order');
        return $this->_authorization->isAllowed('Ced_VivaPayments::view_api_logs') && (bool) ($order && $order->getPayment() && $order->getPayment()->getMethod() === 'paymentmethod');
    }
    public function isHidden(): bool { return false; }
}
