<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Observer;

use Ced\VivaPayments\Service\AttemptManager;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\LocalizedException;

class BlockUncapturedPreauthShipment implements ObserverInterface
{
    private AttemptManager $attempts;

    public function __construct(AttemptManager $attempts)
    {
        $this->attempts = $attempts;
    }

    public function execute(Observer $observer): void
    {
        $shipment = $observer->getEvent()->getShipment();
        $order = $shipment ? $shipment->getOrder() : null;
        if (!$order || !$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') {
            return;
        }
        $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId());
        if ($attempt && !empty($attempt['is_preauth']) && $attempt['order_state'] === 'preauth_payment') {
            throw new LocalizedException(
                __('Shipment is not allowed until the Viva preauthorization has been captured successfully.')
            );
        }
    }
}
