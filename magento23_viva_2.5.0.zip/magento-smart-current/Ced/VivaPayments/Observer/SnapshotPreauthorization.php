<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Observer;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Store\Model\ScopeInterface;

/** Snapshots the product rule onto quote and order at placement time. */
class SnapshotPreauthorization implements ObserverInterface
{
    private ScopeConfigInterface $scopeConfig;

    public function __construct(ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    public function execute(Observer $observer): void
    {
        $quote = $observer->getEvent()->getQuote();
        $order = $observer->getEvent()->getOrder();
        if (!$quote || !$order) { return; }
        $isPreAuth = (bool) $this->scopeConfig->getValue(
            'payment/paymentmethod/preauthorize_all_orders',
            ScopeInterface::SCOPE_STORE,
            (int) $quote->getStoreId()
        );
        if (!$isPreAuth) {
            foreach ($quote->getAllVisibleItems() as $item) {
                $product = $item->getProduct();
                if ($product && (bool) $product->getData('viva_is_preauth')) { $isPreAuth = true; break; }
            }
        }
        $quote->setData('viva_is_preauth', $isPreAuth ? 1 : 0);
        $order->setData('viva_is_preauth', $isPreAuth ? 1 : 0);
    }
}
