<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Observer\Adminhtml;

use Ced\VivaPayments\Service\AttemptManager;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

class ForceOnlineCapture implements ObserverInterface
{
    private OrderRepositoryInterface $orders;
    private AttemptManager $attempts;

    public function __construct(OrderRepositoryInterface $orders, AttemptManager $attempts)
    {
        $this->orders = $orders;
        $this->attempts = $attempts;
    }

    public function execute(Observer $observer): void
    {
        $request = $observer->getEvent()->getControllerAction()->getRequest();
        $orderId = (int) $request->getParam('order_id');
        if (!$orderId) { return; }
        $order = $this->orders->get($orderId);
        if (!$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') { return; }
        $attempt = $this->attempts->getLatestByOrder((string) $order->getIncrementId());
        if (!$attempt || empty($attempt['is_preauth']) || $attempt['order_state'] !== 'preauth_payment') { return; }
        $invoice = (array) $request->getParam('invoice', []);
        $invoice['capture_case'] = 'online';
        $request->setParam('invoice', $invoice);
        $request->setParam('capture_case', 'online');
    }
}
