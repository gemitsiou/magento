<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Observer\Adminhtml;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\InvoiceRepositoryInterface;
use Magento\Sales\Api\OrderRepositoryInterface;

class ForceOnlineRefund implements ObserverInterface
{
    private OrderRepositoryInterface $orders;
    private InvoiceRepositoryInterface $invoices;

    public function __construct(OrderRepositoryInterface $orders, InvoiceRepositoryInterface $invoices)
    {
        $this->orders = $orders;
        $this->invoices = $invoices;
    }

    public function execute(Observer $observer): void
    {
        $request = $observer->getEvent()->getControllerAction()->getRequest();
        $orderId = (int) $request->getParam('order_id');
        $invoiceId = (int) $request->getParam('invoice_id');
        $order = $orderId ? $this->orders->get($orderId) : null;
        if (!$order && $invoiceId) {
            $order = $this->invoices->get($invoiceId)->getOrder();
        }
        if (!$order || !$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') { return; }
        $creditmemo = (array) $request->getParam('creditmemo', []);
        $creditmemo['do_offline'] = 0;
        $request->setParam('creditmemo', $creditmemo);
        $request->setParam('do_offline', 0);
    }
}
