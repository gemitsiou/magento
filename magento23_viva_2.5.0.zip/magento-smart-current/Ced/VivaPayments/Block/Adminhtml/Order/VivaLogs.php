<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Block\Adminhtml\Order;

use Ced\VivaPayments\Service\ApiLogManager;
use Magento\Backend\Block\Template;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Framework\Registry;

class VivaLogs extends Template implements TabInterface
{
    private const PAGE_SIZE = 50;
    private Registry $registry;
    private ApiLogManager $logs;

    public function __construct(Template\Context $context, Registry $registry, ApiLogManager $logs, array $data = [])
    {
        parent::__construct($context, $data);
        $this->registry = $registry;
        $this->logs = $logs;
    }

    public function getLogs(): array
    {
        $order = $this->registry->registry('current_order');
        if (!$order || !$order->getPayment() || $order->getPayment()->getMethod() !== 'paymentmethod') {
            return [];
        }
        return $this->logs->getByOrder(
            (string) $order->getIncrementId(), self::PAGE_SIZE,
            ($this->getCurrentPage() - 1) * self::PAGE_SIZE
        );
    }

    public function getCurrentPage(): int
    {
        return max(1, (int) $this->getRequest()->getParam('viva_log_page', 1));
    }

    public function getPageCount(): int
    {
        $order = $this->registry->registry('current_order');
        if (!$order) { return 1; }
        return max(1, (int) ceil($this->logs->countByOrder((string) $order->getIncrementId()) / self::PAGE_SIZE));
    }

    public function getPageUrl(int $page): string
    {
        $order = $this->registry->registry('current_order');
        return $this->getUrl('sales/order/view', [
            'order_id' => $order ? (int) $order->getId() : 0,
            'viva_log_page' => max(1, $page),
            '_fragment' => 'ced_vivapayments_order_logs_tab',
        ]);
    }

    public function pretty($value): string
    {
        if ($value === null || $value === '') { return '–'; }
        $decoded = json_decode((string) $value, true);
        return json_last_error() === JSON_ERROR_NONE
            ? (string) json_encode($decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
            : (string) $value;
    }

    public function getTabLabel() { return __('Viva Logs'); }
    public function getTabTitle() { return __('Viva Logs'); }
    public function canShowTab(): bool
    {
        $order = $this->registry->registry('current_order');
        return (bool) ($order && $order->getPayment() && $order->getPayment()->getMethod() === 'paymentmethod');
    }
    public function isHidden(): bool { return false; }
}
