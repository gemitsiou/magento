<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Plugin;

use Ced\VivaPayments\Service\AttemptManager;
use Magento\Sales\Model\Order;

class OrderShipmentGuard
{
    private AttemptManager $attempts;

    public function __construct(AttemptManager $attempts)
    {
        $this->attempts = $attempts;
    }

    public function afterCanShip(Order $subject, bool $result): bool
    {
        if (!$result || !$subject->getId() || !$subject->getPayment()
            || $subject->getPayment()->getMethod() !== 'paymentmethod'
        ) {
            return $result;
        }
        $attempt = $this->attempts->getLatestByOrder((string) $subject->getIncrementId());
        return $attempt && !empty($attempt['is_preauth']) && $attempt['order_state'] === 'preauth_payment'
            ? false
            : $result;
    }
}
