/*browser:true*/
/*global define*/
define(
    [
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/model/quote',
        'mage/url'
    ],
    function (Component, quote, url) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Ced_VivaPayments/payment/paymentmethod'
            },
            redirectAfterPlaceOrder: false,
            initialize: function () {
                this._super();
                if (!quote.paymentMethod()) {
                    this.selectPaymentMethod();
                }
                return this;
            },
            /**
             * After place order callback
             */
            afterPlaceOrder: function () {
                window.location.replace(url.build('vivapayments/checkout/start'));
            }
        });
    }
);
