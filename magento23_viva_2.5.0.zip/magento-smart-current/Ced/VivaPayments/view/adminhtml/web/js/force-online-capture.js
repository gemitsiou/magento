define(['domReady!'], function () {
    'use strict';

    function numeric(value) {
        return parseFloat(String(value || '').replace(',', '.'));
    }

    function money(value) {
        var clean = String(value || '').replace(/[^0-9,.-]/g, '');
        if (clean.indexOf(',') !== -1 && clean.indexOf('.') !== -1) {
            clean = clean.lastIndexOf(',') > clean.lastIndexOf('.')
                ? clean.replace(/\./g, '').replace(',', '.')
                : clean.replace(/,/g, '');
        } else if (clean.indexOf(',') !== -1) {
            clean = clean.replace(',', '.');
        }
        return parseFloat(clean);
    }

    return function (config) {
        document.querySelectorAll('[name="invoice[capture_case]"]').forEach(function (field) {
            if (field.tagName === 'SELECT') {
                Array.from(field.options).forEach(function (option) {
                    if (option.value !== 'online') { option.remove(); }
                });
                field.value = 'online';
            } else if (field.value === 'online') {
                field.checked = true;
            } else {
                var wrapper = field.closest('.admin__field-option') || field.parentElement;
                if (wrapper) { wrapper.style.display = 'none'; }
                field.disabled = true;
            }
        });

        var form = document.getElementById('edit_form') || document.querySelector('form');
        var container = document.getElementById('viva-final-shipping-container');
        var fee = document.getElementById('viva-final-shipping-fee');
        var error = document.getElementById('viva-capture-validation');
        if (!form || !container || !fee) { return; }
        form.appendChild(container);
        container.style.display = 'block';

        var quantityInputs = Array.from(form.querySelectorAll('input[name^="invoice[items]"]'));
        function itemsChanged() {
            return quantityInputs.some(function (input) {
                var match = input.name.match(/invoice\[items\]\[(\d+)\]/);
                if (!match || !Object.prototype.hasOwnProperty.call(config.itemQuantities || {}, match[1])) {
                    return false;
                }
                return Math.abs(numeric(input.value) - numeric(config.itemQuantities[match[1]])) > 0.0001;
            });
        }

        function displayedGrandTotal() {
            var total = document.querySelector('.grand_total .price, tr.grand_total .price, [data-ui-id="invoice-totals-grand-total"] .price');
            if (!total) { return NaN; }
            return money(total.textContent || '');
        }

        function validate() {
            var changed = itemsChanged();
            fee.disabled = !changed;
            if (!changed) { fee.value = Number(config.originalShippingFee).toFixed(2); }
            var valid = /^\d+(?:[.,]\d{1,2})?$/.test(fee.value) && numeric(fee.value) >= 0;
            var total = displayedGrandTotal();
            var estimated = isNaN(total)
                ? NaN
                : (total / numeric(config.displayRate || 1)) - numeric(config.originalShippingFee) + numeric(fee.value);
            var exceeds = !isNaN(estimated) && estimated > numeric(config.authorizedAmount) + 0.001;
            error.style.display = changed && (!valid || exceeds) ? 'block' : 'none';
            error.textContent = !valid
                ? 'Final Shipping Fee must be a non-negative number with no more than two decimal places.'
                : (exceeds
                    ? 'The final invoice amount exceeds the authorized amount of ' + Number(config.authorizedAmount).toFixed(2) + ' ' + config.currency + '. Cancel this preauthorization and create a new order.'
                    : '');
            form.querySelectorAll('#submit, button[title="Submit Invoice"], button[data-ui-id*="submit-button"]').forEach(function (button) {
                button.disabled = changed && (!valid || exceeds);
            });
        }

        quantityInputs.forEach(function (input) { input.addEventListener('input', validate); });
        fee.addEventListener('input', validate);
        form.addEventListener('submit', function (event) {
            validate();
            var submitter = event.submitter || null;
            var finalCapture = !submitter || submitter.id === 'submit'
                || (submitter.title || '').toLowerCase() === 'submit invoice';
            if (finalCapture && error.style.display !== 'none') { event.preventDefault(); }
        });
        validate();
    };
});
