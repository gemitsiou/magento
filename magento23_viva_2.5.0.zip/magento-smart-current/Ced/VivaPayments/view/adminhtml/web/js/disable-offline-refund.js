define(['domReady!'], function () {
    'use strict';
    return function () {
        document.querySelectorAll('button').forEach(function (button) {
            var label = (button.textContent || '').trim().toLowerCase();
            if (label === 'refund offline') {
                button.style.display = 'none';
                button.disabled = true;
            }
        });
    };
});
