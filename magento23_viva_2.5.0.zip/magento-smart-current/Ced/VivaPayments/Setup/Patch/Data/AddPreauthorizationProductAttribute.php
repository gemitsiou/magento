<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Magento\Catalog\Model\Product;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class AddPreauthorizationProductAttribute implements DataPatchInterface
{
    private ModuleDataSetupInterface $setup;
    private EavSetupFactory $eavSetupFactory;

    public function __construct(ModuleDataSetupInterface $setup, EavSetupFactory $eavSetupFactory)
    { $this->setup = $setup; $this->eavSetupFactory = $eavSetupFactory; }

    public function apply(): self
    {
        $this->setup->getConnection()->startSetup();
        $eav = $this->eavSetupFactory->create(['setup' => $this->setup]);
        $eav->addAttribute(Product::ENTITY, 'viva_is_preauth', [
            'type' => 'int', 'label' => 'Viva Preauthorization', 'input' => 'boolean',
            'source' => \Magento\Eav\Model\Entity\Attribute\Source\Boolean::class,
            'required' => false, 'default' => 0, 'sort_order' => 250,
            'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
            'group' => 'General', 'visible' => true, 'user_defined' => true,
            'used_in_product_listing' => false,
        ]);
        $entityTypeId = $eav->getEntityTypeId(Product::ENTITY);
        foreach ($eav->getAllAttributeSetIds($entityTypeId) as $attributeSetId) {
            $eav->addAttributeToSet(Product::ENTITY, $attributeSetId, 'General', 'viva_is_preauth');
        }
        $this->setup->getConnection()->endSetup();
        return $this;
    }
    public static function getDependencies(): array { return []; }
    public function getAliases(): array { return []; }
}
