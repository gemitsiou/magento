<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Ced\VivaPayments\Service\CompatibilityChecker;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class ValidateCompatibility implements DataPatchInterface
{
    private CompatibilityChecker $checker;

    public function __construct(CompatibilityChecker $checker)
    {
        $this->checker = $checker;
    }

    public function apply(): self
    {
        $result = $this->checker->getResult();
        if (!$result['compatible']) {
            throw new LocalizedException(__($this->checker->getMessage($result)));
        }
        return $this;
    }

    public static function getDependencies(): array { return []; }
    public function getAliases(): array { return []; }
}
