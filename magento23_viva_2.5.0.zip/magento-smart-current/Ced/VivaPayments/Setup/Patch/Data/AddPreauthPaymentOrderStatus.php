<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\StatusFactory;

class AddPreauthPaymentOrderStatus implements DataPatchInterface
{
    private ModuleDataSetupInterface $setup;
    private StatusFactory $statusFactory;

    public function __construct(ModuleDataSetupInterface $setup, StatusFactory $statusFactory)
    {
        $this->setup = $setup;
        $this->statusFactory = $statusFactory;
    }

    public function apply(): self
    {
        $this->setup->getConnection()->startSetup();
        $status = $this->statusFactory->create()->load('preauth_payment');
        if (!$status->getStatus()) {
            $status->setData(['status' => 'preauth_payment', 'label' => 'Preauth Payment'])->save();
        }
        $status->assignState(Order::STATE_PROCESSING, false, true);
        $this->setup->getConnection()->endSetup();
        return $this;
    }

    public static function getDependencies(): array { return []; }
    public function getAliases(): array { return []; }
}
