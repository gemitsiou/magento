<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class EncryptExistingApiKey implements DataPatchInterface
{
    private ResourceConnection $resource;
    private EncryptorInterface $encryptor;

    public function __construct(ResourceConnection $resource, EncryptorInterface $encryptor)
    {
        $this->resource = $resource;
        $this->encryptor = $encryptor;
    }

    public function apply(): self
    {
        $connection = $this->resource->getConnection();
        $table = $this->resource->getTableName('core_config_data');
        $rows = $connection->fetchAll(
            $connection->select()->from($table, ['config_id', 'value'])
                ->where('path = ?', 'payment/paymentmethod/merchantpass')
        );
        foreach ($rows as $row) {
            $value = (string) ($row['value'] ?? '');
            if ($value === '' || preg_match('/^\d+:\d+:/', $value)) { continue; }
            $connection->update(
                $table,
                ['value' => $this->encryptor->encrypt($value)],
                ['config_id = ?' => (int) $row['config_id']]
            );
        }
        return $this;
    }

    public static function getDependencies(): array { return []; }
    public function getAliases(): array { return []; }
}
