<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Setup\Patch\Data;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class RenamePaymentMethodTitle implements DataPatchInterface
{
    private ResourceConnection $resource;

    public function __construct(ResourceConnection $resource)
    {
        $this->resource = $resource;
    }

    public function apply(): self
    {
        $connection = $this->resource->getConnection();
        $connection->update(
            $this->resource->getTableName('core_config_data'),
            ['value' => 'Viva.com Smart Checkout'],
            [
                'path = ?' => 'payment/paymentmethod/title',
                'value IN (?)' => ['Credit Card (Viva Wallet Smart Checkout)', 'Viva Wallet Smart Checkout'],
            ]
        );
        return $this;
    }

    public static function getDependencies(): array { return []; }
    public function getAliases(): array { return []; }
}
