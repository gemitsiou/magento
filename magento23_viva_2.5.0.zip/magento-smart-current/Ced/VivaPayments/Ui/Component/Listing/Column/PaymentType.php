<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Ui\Component\Listing\Column;

use Magento\Ui\Component\Listing\Columns\Column;

class PaymentType extends Column
{
    public function prepareDataSource(array $dataSource): array
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $value = (string) ($item[$this->getData('name')] ?? '');
                $item[$this->getData('name')] = $value === 'preauthorization'
                    ? (string) __('Preauthorization')
                    : ($value === 'one_off' ? (string) __('One-off Payment') : '–');
            }
        }
        return $dataSource;
    }
}
