<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Controller\Viva;

use Ced\VivaPayments\Service\OrderProcessor;
use Ced\VivaPayments\Service\AttemptManager;
use Ced\VivaPayments\Service\PaymentPoller;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Message\ManagerInterface as MessageManager;
use Psr\Log\LoggerInterface;

/**
 * Handles the customer return from Viva Wallet after payment.
 *
 * This is a customer-browser redirect (not a server-to-server webhook).
 * Security is ensured by verifying the transaction with Viva's API using
 * the order code — if Viva confirms the transaction, it's authentic.
 *
 * CSRF note: Since this is a GET redirect from an external site, traditional
 * form keys are not available. The Viva API transaction verification serves
 * as the authentication mechanism (order codes are unguessable and tied to
 * authenticated merchant API credentials).
 */
class Callback implements HttpGetActionInterface
{
    private PaymentPoller $paymentPoller;
    private AttemptManager $attemptManager;
    private OrderProcessor $orderProcessor;
    private CheckoutSession $checkoutSession;
    private RedirectFactory $redirectFactory;
    private MessageManager $messageManager;
    private LoggerInterface $logger;
    private RequestInterface $request;

    public function __construct(
        PaymentPoller $paymentPoller,
        AttemptManager $attemptManager,
        OrderProcessor $orderProcessor,
        CheckoutSession $checkoutSession,
        RedirectFactory $redirectFactory,
        MessageManager $messageManager,
        LoggerInterface $logger,
        RequestInterface $request
    ) {
        $this->paymentPoller = $paymentPoller;
        $this->attemptManager = $attemptManager;
        $this->orderProcessor = $orderProcessor;
        $this->checkoutSession = $checkoutSession;
        $this->redirectFactory = $redirectFactory;
        $this->messageManager = $messageManager;
        $this->logger = $logger;
        $this->request = $request;
    }

    /**
     * Process payment callback from Viva Wallet.
     */
    public function execute(): Redirect
    {
        try {
            return $this->processCallback();
        } catch (\Exception $e) {
            $this->logger->error('VivaPayments Callback unexpected error', [
                'exception' => $e->getMessage(),
            ]);
            $this->messageManager->addErrorMessage(
                __('An error occurred processing your payment. Please contact support.')
            );
            return $this->redirectToCart();
        }
    }

    /**
     * Core callback processing logic.
     */
    private function processCallback(): Redirect
    {
        $orderCode = (string) $this->request->getParam('s', '');
        $transactionId = (string) $this->request->getParam('t', '');
        $customerCancelled = (string) $this->request->getParam('cancel', '') === '1';

        if (empty($orderCode)) {
            $this->logger->error('VivaPayments Callback: Missing order code parameter');
            $this->messageManager->addErrorMessage(
                __('Invalid payment callback. Missing payment reference.')
            );
            return $this->redirectToCart();
        }

        // Load the Magento order via the Viva order code stored in vivapayments_data.
        // This is session-independent: the order code is the authoritative link.
        try {
            $order = $this->orderProcessor->loadOrderByVivaCode($orderCode);
        } catch (NoSuchEntityException $e) {
            $this->logger->error('VivaPayments Callback: Cannot load order for code', [
                'order_code' => $orderCode,
            ]);
            $this->messageManager->addErrorMessage(
                __('Unable to retrieve your order. Please contact support.')
            );
            return $this->redirectToCart();
        }

        $attempt = $this->attemptManager->getByOrderCode($orderCode);
        if (!$attempt) {
            $this->messageManager->addErrorMessage(__('Unable to retrieve the payment attempt.'));
            return $this->redirectToCart();
        }

        if ($customerCancelled) {
            $this->logger->info('Viva customer cancellation callback', [
                'order_code' => $orderCode,
                'transaction_id' => $transactionId,
                'cancel' => 1,
                'magento_order' => $order->getIncrementId(),
            ]);
            // Required order: stop transaction polling, immediately DELETE the Viva payment
            // order, then cancel Magento and restore the customer's basket.
            $this->paymentPoller->cancelPaymentOrder($attempt);
            $this->orderProcessor->processCustomerCancellation($order);
            $this->checkoutSession->restoreQuote();
            $this->messageManager->addNoticeMessage(
                __('Your payment was cancelled and your basket has been restored.')
            );
            return $this->redirectToCart();
        }

        // One final API call is made on return. If t is present it must match exactly;
        // the API client never falls back to the latest transaction.
        $verification = $this->paymentPoller->pollAttempt(
            $attempt,
            true,
            $transactionId !== '' ? $transactionId : null
        );

        if ($verification['verified']) {
            // Successful payment
            return $this->redirectToSuccess();
        }

        $state = (string) ($verification['state'] ?? 'verification_error');
        if (in_array($state, ['failed', 'expired'], true)) {
            $this->checkoutSession->restoreQuote();
            $this->messageManager->addErrorMessage(
                $state === 'expired'
                    ? __('Your payment session expired. Your basket has been restored.')
                    : __('Your transaction was unsuccessful. Your basket has been restored.')
            );
            return $this->redirectToCart();
        }

        // Empty, pending or technical/identity validation results remain pending_payment.
        // Do not restore the quote, which prevents an accidental duplicate payment.
        $this->messageManager->addNoticeMessage(
            __('Your payment verification is pending. Please do not submit another payment for this order.')
        );
        return $this->redirectToSuccess();
    }

    private function redirectToSuccess(): Redirect
    {
        /** @var Redirect $redirect */
        $redirect = $this->redirectFactory->create();
        $redirect->setPath('checkout/onepage/success');
        return $redirect;
    }

    private function redirectToCart(): Redirect
    {
        /** @var Redirect $redirect */
        $redirect = $this->redirectFactory->create();
        $redirect->setPath('checkout/cart');
        return $redirect;
    }
}
