<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Console\Command;

use Ced\VivaPayments\Service\CompatibilityChecker;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CheckCompatibility extends Command
{
    private CompatibilityChecker $checker;

    public function __construct(CompatibilityChecker $checker)
    {
        $this->checker = $checker;
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->setName('viva:compatibility:check')
            ->setDescription('Check Magento and PHP compatibility for Viva.com Smart Checkout');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $result = $this->checker->getResult();
        $output->writeln($this->checker->getMessage($result));
        $output->writeln($result['compatible'] ? '<info>Compatible</info>' : '<error>Not compatible</error>');
        return $result['compatible'] ? Command::SUCCESS : Command::FAILURE;
    }
}
