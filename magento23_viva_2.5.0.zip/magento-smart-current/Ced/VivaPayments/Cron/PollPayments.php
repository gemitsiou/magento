<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Cron;

use Ced\VivaPayments\Service\PaymentPoller;

class PollPayments
{
    private PaymentPoller $poller;
    public function __construct(PaymentPoller $poller) { $this->poller = $poller; }
    public function execute(): void { $this->poller->pollDue(); }
}
