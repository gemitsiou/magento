# Viva Payments systemd worker

Install once, after deploying the Magento module and completing `setup:upgrade` and DI compilation:

```bash
cd app/code/Ced/VivaPayments/deployment/systemd
sudo bash install-worker.sh /absolute/path/to/magento MAGENTO_OS_USER /usr/bin/php
```

Example:

```bash
sudo bash install-worker.sh /home/gmitsiou/htdocs/www.gmitsiou.tech gmitsiou /usr/bin/php
```

The service starts at boot, restarts after failure, and gracefully recycles every hour. Admin configuration is reloaded every 30 seconds without requiring a manual service restart.

Useful checks:

```bash
systemctl is-active ced-vivapayments-poll.service
systemctl status ced-vivapayments-poll.service --no-pager
journalctl -u ced-vivapayments-poll.service -n 100 --no-pager
```
