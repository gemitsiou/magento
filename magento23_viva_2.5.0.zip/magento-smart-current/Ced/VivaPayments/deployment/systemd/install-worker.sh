#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 2 ] || [ "$#" -gt 3 ]; then
    echo "Usage: sudo bash install-worker.sh MAGENTO_ROOT MAGENTO_USER [PHP_BINARY]" >&2
    exit 2
fi

magento_root="${1%/}"
magento_user="$2"
php_binary="${3:-/usr/bin/php}"
service_name="ced-vivapayments-poll.service"
script_dir="$(cd "$(dirname "$0")" && pwd)"
template_path="$script_dir/$service_name.dist"

if [ ! -f "$magento_root/bin/magento" ]; then
    echo "Magento CLI not found at $magento_root/bin/magento" >&2
    exit 1
fi
if ! id "$magento_user" >/dev/null 2>&1; then
    echo "System user not found: $magento_user" >&2
    exit 1
fi
if [ ! -x "$php_binary" ]; then
    echo "PHP binary is not executable: $php_binary" >&2
    exit 1
fi

magento_group="$(id -gn "$magento_user")"
escape_sed() { printf '%s' "$1" | sed 's/[&|]/\\&/g'; }
root_escaped="$(escape_sed "$magento_root")"
user_escaped="$(escape_sed "$magento_user")"
group_escaped="$(escape_sed "$magento_group")"
php_escaped="$(escape_sed "$php_binary")"
temporary_unit="$(mktemp)"
trap 'rm -f "$temporary_unit"' EXIT

sed \
    -e "s|__MAGENTO_ROOT__|$root_escaped|g" \
    -e "s|__MAGENTO_USER__|$user_escaped|g" \
    -e "s|__MAGENTO_GROUP__|$group_escaped|g" \
    -e "s|__PHP_BINARY__|$php_escaped|g" \
    "$template_path" > "$temporary_unit"

install -o root -g root -m 0644 "$temporary_unit" "/etc/systemd/system/$service_name"
systemctl daemon-reload
systemctl enable --now "$service_name"
systemctl --no-pager --full status "$service_name"
