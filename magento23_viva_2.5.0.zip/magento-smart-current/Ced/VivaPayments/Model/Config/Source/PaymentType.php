<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

class PaymentType implements OptionSourceInterface
{
    public function toOptionArray(): array
    {
        return [
            ['value' => 'preauthorization', 'label' => __('Preauthorization')],
            ['value' => 'one_off', 'label' => __('One-off Payment')],
        ];
    }
}
