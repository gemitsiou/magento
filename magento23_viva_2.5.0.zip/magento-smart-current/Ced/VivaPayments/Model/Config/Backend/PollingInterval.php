<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Model\Config\Backend;

use Magento\Framework\App\Config\Value;
use Magento\Framework\Exception\LocalizedException;

class PollingInterval extends Value
{
    public function beforeSave(): self
    {
        $value = (string) $this->getValue();
        if (!preg_match('/^\d+$/', $value) || (int) $value < 5) {
            throw new LocalizedException(__('Polling Interval must be an integer of at least 5 seconds.'));
        }
        $this->setValue((int) $value);
        return parent::beforeSave();
    }
}
