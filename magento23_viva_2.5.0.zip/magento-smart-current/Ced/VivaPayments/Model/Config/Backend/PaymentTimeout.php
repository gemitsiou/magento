<?php
declare(strict_types=1);

namespace Ced\VivaPayments\Model\Config\Backend;

use Magento\Framework\App\Config\Value;
use Magento\Framework\Exception\LocalizedException;

class PaymentTimeout extends Value
{
    public function beforeSave(): self
    {
        $value = (string) $this->getValue();
        if (!preg_match('/^\d+$/', $value) || (int) $value < 1 || (int) $value > 65535) {
            throw new LocalizedException(__('Order Payment Timeout must be an integer between 1 and 65535 seconds.'));
        }
        $this->setValue((int) $value);
        return parent::beforeSave();
    }
}
