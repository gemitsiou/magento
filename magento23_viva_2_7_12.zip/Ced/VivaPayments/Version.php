<?php
declare(strict_types=1);

namespace Ced\VivaPayments;

/**
 * Explicit module version for deployments where Composer package metadata is unavailable.
 */
final class Version
{
    public const VERSION = '2.7.12';

    private function __construct()
    {
    }
}
