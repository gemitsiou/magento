<?php
declare(strict_types=1);
$root = dirname(__DIR__, 2);
$checks = [
 'version' => str_contains(file_get_contents($root.'/composer.json'), '"version": "2.7.12"'),
 'explicit_version_constant' => is_file($root.'/Version.php') && str_contains(file_get_contents($root.'/Version.php'), "public const VERSION = '2.7.12'"),
 'admin_tabs_tabinterface' => str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaInfo.php'), 'implements TabInterface') && str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaLogs.php'), 'implements TabInterface'),
 'admin_tabs_not_acl_hidden' => !str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaInfo.php'), "isAllowed('Ced_VivaPayments::view_payment_info') &&") && !str_contains(file_get_contents($root.'/Block/Adminhtml/Order/VivaLogs.php'), "isAllowed('Ced_VivaPayments::view_api_logs') &&"),
 'reconcile_acl' => str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), "ADMIN_RESOURCE = 'Ced_VivaPayments::reconcile'"),
 'reconcile_post' => str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'HttpPostActionInterface'),
 'no_blind_refund' => !str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'refundTransaction('),
 'no_blind_capture' => !str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'capturePreauthorization('),
 'no_blind_cancel' => !str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'cancelPreauthorization('),
 'no_blind_create' => !str_contains(file_get_contents($root.'/Controller/Adminhtml/Order/Reconcile.php'), 'createPaymentOrder('),
 'callback_no_transaction_fallback' => str_contains(file_get_contents($root.'/Service/VivaApiClient.php'), 'if (!empty($transactionId))') && str_contains(file_get_contents($root.'/Service/VivaApiClient.php'), 'return null;'),
 'granular_acl' => str_contains(file_get_contents($root.'/etc/acl.xml'), 'view_payment_info') && str_contains(file_get_contents($root.'/etc/acl.xml'), 'view_api_logs'),
 'quote_submit_plugin_registered' => str_contains(file_get_contents($root.'/etc/di.xml'), 'ced_vivapayments_quote_submit_idempotency'),
 'quote_submit_viva_scoped' => str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), "PAYMENT_METHOD = 'paymentmethod'"),
 'quote_submit_lock' => str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), 'ced_viva_quote_submit_') && str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), 'finally'),
 'quote_submit_existing_order_reuse' => str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), "where('quote_id = ?'") && str_contains(file_get_contents($root.'/Plugin/QuoteSubmitIdempotency.php'), 'orderRepository->get'),
 'frontend_single_submit' => str_contains(file_get_contents($root.'/view/frontend/web/template/payment/paymentmethod.html'), "enable: (getCode() == isChecked()) && isPlaceOrderActionAllowed()"),
];
foreach ($checks as $name=>$ok) { echo ($ok?'PASS ':'FAIL ').$name.PHP_EOL; if (!$ok) exit(1); }
